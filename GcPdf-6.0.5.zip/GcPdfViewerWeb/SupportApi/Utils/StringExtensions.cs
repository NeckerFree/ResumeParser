﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Utils
{
    enum BooleanAliases
    {
        TRUE = 1,
        YES = 1,
        ON = 1,
        DA = 1,
        FALSE = 0,
        OFF = 0,
        NO = 0,
        NET = 0
    }

    public static class StringExtensions
    {

        public static bool ToBoolean(this string str, bool defaultValue = false)
        {
            if (string.IsNullOrEmpty(str)) return defaultValue;
            if (bool.TryParse(str, out bool boolVal)) return boolVal;
            if (Enum.TryParse(str.ToUpperInvariant(), out BooleanAliases val)) return Convert.ToBoolean((int)val);
            return defaultValue;
        }

		/// <summary>
		/// Convert from client base64 encoded UTF8 string to UTF8 string.
		/// Encode function used on client side: window.btoa(unescape(encodeURIComponent(str))
		/// </summary>
		/// <param name="str">base64 encoded string</param>
		/// <returns>Decoded UTF8 string</returns>
		public static string Base64ToUtf8(this string str)
        {
            try
            {
                if (!str.IsBase64())
                    return str; // string not in base64 format
				return Encoding.UTF8.GetString(Convert.FromBase64String(str));
			}
            catch (FormatException)
            {
				// string not in base64 format
				return str;
            }
			catch
			{
#if DEBUG
				throw;
#else
                return str;
#endif
			}
		}

		/// <summary>
		/// Test if string is in base64 encoded format.
		/// </summary>
		/// <param name="str"></param>
		/// <returns>bool</returns>
		[System.Diagnostics.DebuggerNonUserCode()]
		public static bool IsBase64(this string str)
		{
			if (str == null || str.Length == 0 || str.Length % 4 != 0 || str.Contains(' ') || str.Contains('\t') || str.Contains('\r') || str.Contains('\n'))
				return false;
			try
			{
				// Best solution for any string value
				string decoded = Encoding.UTF8.GetString(Convert.FromBase64String(str));
				string encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(decoded));
				if (str.Equals(encoded, StringComparison.InvariantCultureIgnoreCase))
				{
					return true;
				}
			}
			catch (FormatException)
			{
				// ignore
			}
			catch (Exception)
			{
				// ignore
#if DEBUG
				throw;
#endif
			}
			return false;
		}

	}
}
