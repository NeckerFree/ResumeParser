﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Utils
{
    public class ReflectionUtils
    {

        /// <summary>
        /// Returns the additional assembly version name if any, otherwise returns the standard assembly version number (4 digits).
        /// </summary>
        /// <param name="assembly"></param>
        /// <param name="fallbackVersionFieldsCount"></param>
        /// <returns></returns>
        public static string GetInformationalVersion(Assembly assembly, int fallbackVersionFieldsCount = 4)
        {
            var AssemblyInformationalVersionAttribute = assembly.GetCustomAttributes(typeof(AssemblyInformationalVersionAttribute), false) as AssemblyInformationalVersionAttribute[];
            if (AssemblyInformationalVersionAttribute != null && AssemblyInformationalVersionAttribute.Length > 0)
            {
                return AssemblyInformationalVersionAttribute[0].InformationalVersion;
            }
            else
            {
                return assembly.GetName().Version.ToString(fallbackVersionFieldsCount);
            }
        }
    }
}
