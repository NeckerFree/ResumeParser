﻿using GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration
{
    public class StartSharedModeResponse
    {
        public StartSharedModeResponse(ModificationsState modifications, UserAccess userAccess, List<UserAccess> userAccessList)
        {
            this.modifications = modifications;
            this.userAccess = userAccess;
            this.userAccessList = userAccessList;
        }

        public ModificationsState modifications { get; set; }

        public UserAccess userAccess { get; set; }

        public List<UserAccess> userAccessList { get; set; }
    }
}
