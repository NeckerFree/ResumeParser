﻿using GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration
{
    public class StopSharedModeResponse
    {
        public StopSharedModeResponse()
        {
            
        }

    }
}
