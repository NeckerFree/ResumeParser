﻿namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration
{
    /// <summary>
    /// Specifies the type of a shared document modification.
    /// </summary>
    public enum ModificationType
    {
        /// <summary>
        /// No changes.
        /// </summary>
        NoChanges = 0,
        /// <summary>
        /// Document structure change.
        /// </summary>
        Structure = 1,
        /// <summary>
        /// Annotation removed.
        /// </summary>
        RemoveAnnotation = 2,
        /// <summary>
        /// Annotation added.
        /// </summary>
        AddAnnotation = 3,
        /// <summary>
        /// Annotation updated.
        /// </summary>
        UpdateAnnotation = 4,
        /// <summary>
        /// Undo.
        /// </summary>
        Undo = 5,
        /// <summary>
        /// Redo.
        /// </summary>
        Redo = 6,
    }
}
