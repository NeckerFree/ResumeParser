﻿using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;
using System;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Localization
{
    /// <summary>
    /// SupportApi localization.
    /// </summary>
    public sealed class Localizer
    {

        #region ** fields

        private static CultureInfo _culture;

        #endregion

        /// <summary>
        /// SupportApi culture.        
        /// </summary>
        /// <example>
        /// ViewerSupportApi.Localization.Localizer.Culture = CultureInfo.GetCultureInfo("ja-JP");
        /// </example>
        public static CultureInfo Culture
        {
            get
            {
                return _culture ?? CultureInfo.CurrentCulture;
            }
            set {
                _culture = value; 
                GcPdfViewerController.Settings.ErrorMessages = Localizer.GetErrorMessages();
            }
        }

        /// <summary>
        /// Gets localized error messages.
        /// </summary>
        /// <returns></returns>
        public static ErrorMessages GetErrorMessages()
        {            
            if (Culture.TwoLetterISOLanguageName == "ja")
                return new ErrorMessages_Ja();
            else
                return new ErrorMessages();
        }

        /// <summary>
        /// Get localized string.
        /// </summary>
        /// <param name="key"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static string Get(string key, string defaultValue)
        {
            try
            {
                var s = ResStrings.GetString(key, Culture);
                if (string.IsNullOrEmpty(s))
                    return defaultValue;
                return s;
            }
            catch (Exception)
            {
#if DEBUG
                throw;
#else
                return defaultValue;
#endif
            }
        }

        /// <summary>
        /// Get localized image resource.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static byte[] GetImageBytes(string categoryEnName, string keyWithoutExt)
        {
            try
            {
                Stream imStream = GetEmbeddedResx($"Images.Stamps_{Culture.TwoLetterISOLanguageName}.{categoryEnName}.{keyWithoutExt}.png");
                if (imStream == null)
                {
                    imStream = GetEmbeddedResx($"Images.Stamps.{categoryEnName}.{keyWithoutExt}.png");
                }
                    
                if (imStream != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        imStream.CopyTo(ms);
                        return ms.ToArray();
                    }
                }
                return null;
            }
            catch (Exception)
            {
#if DEBUG
                throw;
#else
                return null;
#endif
            }
        }

        private static Stream GetEmbeddedResx(string resourceName)
        {
            Assembly assembly = typeof(Localizer).Assembly;
            Stream stream = assembly.GetManifestResourceStream(typeof(Localizer), resourceName);
            return stream;
        }

    }
}
