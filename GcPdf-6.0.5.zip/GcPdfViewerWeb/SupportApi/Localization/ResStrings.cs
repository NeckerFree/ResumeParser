﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Localization
{
    public class ResStrings
    {
        static string _langName;
        static Dictionary<string, string> _stringVals;
        internal static string GetString(string key, CultureInfo culture)
        {
            var langName = culture.TwoLetterISOLanguageName;
            if (_stringVals == null || _langName != langName)
            {
                _langName = langName;
                _ReadStrings();
            }
            lock (_stringVals)
            {
                if(_stringVals.TryGetValue(key, out string val))
                {
                    return val;
                }
            }
            return "";
        }

        static void _ReadStrings()
        {
            _stringVals = new Dictionary<string, string>();
            lock (_stringVals)
            {
                if (_langName == "ja")
                {
                    _stringVals.Add("EmbeddedStampImagesStorage.Dynamics", "ダイナミック");
                    _stringVals.Add("EmbeddedStampImagesStorage.Sign", "署名");
                    _stringVals.Add("EmbeddedStampImagesStorage.StandardBusiness", "標準");
                    _stringVals.Add("EmbeddedStampImagesStorage.Stamps", "スタンプ");
                }
                else
                {
                    _stringVals.Add("EmbeddedStampImagesStorage.Dynamics", "Dynamics");
                    _stringVals.Add("EmbeddedStampImagesStorage.Sign", "Sign");
                    _stringVals.Add("EmbeddedStampImagesStorage.StandardBusiness", "Standard Business");
                    _stringVals.Add("EmbeddedStampImagesStorage.Stamps", "Stamps");
                }
            }
        }
    }
}
