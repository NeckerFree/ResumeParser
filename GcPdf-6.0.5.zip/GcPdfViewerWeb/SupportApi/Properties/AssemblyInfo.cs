using System.Reflection;

[assembly: AssemblyTitle("GrapeCity.Documents.Pdf.ViewerSupportApi")]
[assembly: AssemblyProduct("GrapeCity.Documents")]
[assembly: AssemblyDescription("GrapeCity Documents SupportApi for GcPdfViewer")]
[assembly: AssemblyCompany("GrapeCity, Inc.")]
[assembly: AssemblyCopyright("(c) GrapeCity, Inc. All rights reserved.")]
[assembly: AssemblyFileVersion("0.0.0.0")]
[assembly: AssemblyVersion("0.0.0.0")]
