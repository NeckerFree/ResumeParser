﻿using GrapeCity.Documents.Pdf.ViewerSupportApi.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Connection
{

    /// <summary>
    /// Represents a client message.
    /// </summary>
    public class ClientMessage : Message
    {
        /// <summary>
        /// Gets or sets the client id.
        /// </summary>
        public string clientId { get; set; }

        /// <summary>
        /// Gets or sets the type of client message or request.
        /// </summary>
        public ClientMessageOrRequestType type { get; set; }
    }

    /// <summary>
    /// Specifies the type of a client message or request.
    /// </summary>
    public enum ClientMessageOrRequestType
    {
        // Messages:
        /// <summary>Message: start.</summary>
        Start = 1,
        /// <summary>Message: stop.</summary>
        Stop = 2,
        /// <summary>Message: share document.</summary>
        ShareDocument = 10,
        /// <summary>Message: stop sharing document.</summary>
        UnshareDocument = 11,
        /// <summary>Message: modification.</summary>
        Modification = 20,
        /// <summary>Message: reconnect.</summary>
        Reconnect = 30,
        // Request messages:
        /// <summary>Request: user access list.</summary>
        UserAccessList = 100,
        /// <summary>Request: shared documents list.</summary>
        SharedDocumentsList = 101,
        /// <summary>Request: all users list.</summary>
        AllUsersList = 102,
        /// <summary>Request: .</summary>
        OpenSharedDocument = 103,
        /// <summary>Request: start shared mode.</summary>
        StartSharedMode = 104,
        /// <summary>Request: stop shared mode.</summary>
        StopSharedMode = 105,
    }
}
