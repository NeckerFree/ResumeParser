# Changelog
All notable changes to this project will be documented in this file.

## [unreleased]
## Fixed
- [GcPdfViewer] Can not see signer name in viewer if signer name is JP characters. (DOC-5145)

## [6.0.4] - 03-Feb-2023
## Fixed
- Filling and saving a signed form in GcPdfViewer invalidates the signature. (DOC-5090)

## [6.0.3] - 18-Jan-2023
## Fixed
- Checkbox widgets with the same name did not work correctly. (DOC-4874)

## [6.0.2] - 30-Dec-2022
### Fixed
- Converting stamp annotations to content yields incorrect results in some cases. (DOC-5011, DOC-5012)
- Zooming PDF pages with negative media box offsets may produce blank pages. (DOC-5015)

## [6.0.1] - 27-Dec-2022
### Added
- Added the ability to save PDFs using incremental update or linearized mode. (DOC-4913)
```csharp
// Example: save documents as linearized PDFs:
public void Configuration(IAppBuilder app)
{
  GcPdfViewerController.Settings.SaveMode = SaveMode.Linearized;
  // ...
}
```
- Added electronic signature API. (DOC-4951)
```csharp
// Example: electronically sign PDFs with a .PFX certificate:
public void Configuration(IAppBuilder app) {
  GcPdfViewerController.Settings.Sign += _OnSign;
  // ...
}
private void _OnSign(object sender, SignEventArgs e)
{
    var signatureProperties = e.SignatureProperties;
    X509Certificate2 certificate = new X509Certificate2(
      System.IO.File.ReadAllBytes("certificate.pfx"), "password", 
      X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
    signatureProperties.SignatureBuilder = new Pkcs7SignatureBuilder()
    {
       CertificateChain = new X509Certificate2[] { certificate },
       HashAlgorithm = Security.OID.HashAlgorithms.SHA512,
       Format = Pkcs7SignatureBuilder.SignatureFormat.adbe_pkcs7_detached
    };
}
```
### Fixed
- Redundant '+' character appears in the file name when saving a document. (DOC-4934)

## [6.0.0] - 25-Nov-2022
- Added SaveAsImage method: saves the pages of the current PDF document as a zip archive with page images. (DOC-4577)
- Added support for text markup annotations. (DOC-4471)
### Fixed
- Redact annotation lost after save current document. (DOC-4765)
- Operation is not valid due to the current state of the object when attaching Stamp Anotation to user Pdf. (DOC-4860)
- Miscellaneous bug fixes. (DOC-4777, DOC-4775)

## [5.2.0.804] - 02-Nov-2022
### Fixed
- [Regression from v5.2.0.803] An annotation that is converted to content and redacted is not removed from the document. (DOC-4746)
- PDF is saved incorrectly if it contains intersecting annotations and redacts (fix requires GcPdfViewer v3.2.4 or later). (Additional fixes for DOC-4722, DOC-4720)

## [5.2.0.803] - 20-Oct-2022
### Fixed
- When saving a PDF containing double bytes in the name, the double bytes are removed from the file name. (DOC-4657)
- PDF is saved incorrectly if it contains intersecting annotations and redacts. (DOC-4722, DOC-4720)

## [5.1.0.795] - 14-Jul-2022
### Fixed
[Regression] - Stamp annotation's image changed after save modified document. (DOC-4464)
[Regression] - Signature lost after save modified document. (DOC-4462)

## [5.1.0.794] - 13-Jul-2022
### Fixed
- Stamp annotation becomes larger after save modified pdf. (DOC-4318)

## [5.1.0.793] - 06-Jun-2022
### Fixed
- [DioDocs package] The predefined default stamps are not localized. (DOC-4327)
- Modified value of a Combobox cannot be saved if it is custom (requires GcPdfViewer v3.1.5 or later). (DOC-4280)
### Added
- [ASP .Net Core version] Added CorsProxy method. Use this method to open PDF documents from another domain.
  Usage example:
  viewer.open("http://localhost:5005/api/pdf-viewer/CorsProxy?url=https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf");

## [5.1.0.791] - 27-Apr-2022
### Fixed
- Rotate angle changed in exported pdf in some cases. (DOC-4193)

## [5.1.0.790] - 08-Apr-2022
### Added
- Added support for stamp rotation.
### Changed
- Starting with this build, SupportApi version will be synced with other GrapeCity.Documents packages.
### Fixed
- [Collaboration] Fixed problem with PDF document fingerprint id serialization between clients. (DOC-4143)
- [Collaboration] The PDF file name is displayed incorrectly in the "Manage Access". (DOC-4144)

## [2.2.16] - 15-Feb-2022
### Changed
- Project namespace changed from "SupportApi" to "GrapeCity.Documents.Pdf.ViewerSupportApi".
Please, update your "usings" definitions, e.g.:
replace 
using SupportApi.Controllers;
by 
using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;

## [2.1.16] - 17-Mar-2022
### Fixed
- In some cases, the visibility state of layers is incorrect after saving a PDF file. (DOC-4067)

## [2.1.15] - 20-Jan-2022
### Added
- Added support for new tab order types: "Annotations" and "Widgets".
### Fixed
- Cannot reset the "Tab order" property to "Not specified". (DOC-3968)

## [2.1.13] - 20-Dec-2021
### Added
- [ComboBox] Added support for Editable property. (DOC-3947)

## [2.1.12] - 14-Dec-2021
### Added
- Added the ability to keep visibility state for optional content groups when saving a document. (DOC-3652)
- Japanese localization for stamp images.
### Fixed
- [WebForms] Fixed problem with camelCase property names serialization.
- [WebForms] Fixed problem with loading localization resources.

## [2.1.11] - 26-Nov-2021
### Fixed
- Fixed: In some rare cases the collaborative mode can hang the IIS service when the service is running on the UI thread.

## [2.1.10] - 25-Nov-2021
### Fixed
- Fixed: A draft image is displayed in the stamp annotation even if the image was removed using the annotation editor. (DOC-3064)

## [2.1.9] - 12-Nov-2021
### Fixed
- Checkbox value "Off" not saved.

## [2.1.8] - 01-Nov-2021
### Fixed
- Fixed issue with annotationName and contents properties for LinkAnnotation. (DOC-3680)

## [2.1.7] - 29-Oct-2021
### Fixed
- Reset buttons not saved for GcPdfViewer v3.0.*.

## [2.1.6] - 01-Oct-2021
### Fixed
- The request type for version / lastError requests from the viewer has been changed to POST. (DOC-3656)

## [2.1.5] - 29-Sep-2021
### Fixed
- Fixed problem with "Void" stamp image localization.

## [2.1.4] - 22-Sep-2021
### Added
- Added ability to localize stamp images and strings.
  Localization strings location:
    SupportApi\Localization\StringsTable.resx
  Localization images location:
    SupportApi\Localization\ImagesTable.resx
  Here's an example how to change the localization language:
```csharp
  SupportApi.Localization.Localizer.Culture = CultureInfo.GetCultureInfo("ja-JP");
```

## [2.1.3] - 15-Sep-2021
### Fixed
- Incorrect annotation name after saving the document and re-loading for code added annotation. (DOC-3619)

## [2.1.2] - 29-Jul-2021
### Fixed
- Error saving document after adding all predefined stamps to canvas. (DOC-3358)

## [2.1.1] - 23-Jul-2021
### Fixed
- On changing the Required field to true, the field name gets changed and only last part of hierarchy fields. (DOC-3449)

## [2.0.8] - 20-Jul-2021
### Fixed
- The opacity effect looks different from Adobe. (DOC-3359)

## [2.0.7] - 29-Jun-2021
### Added
- Predefined stamps support. (DOC-3130)

## [2.0.6] - 09-Jun-2021
### Added
- Added ability to modify page's fields Tab order using the Form Editor. (DOC-3168)
- Added ability to modify page size. (DOC-2751)

## [2.0.5] - 25-May-2021
### Fixed
- Fixed null reference exception in some rare cases when applying client changes to annotations.

## [2.0.4] - 28-Apr-2021
### Added
- Added font name support for text fields and free text annotations. (DOC-3132)

## [2.0.3] - 20-Apr-2021
### Fixed
- There's no file for FileAttachment annotation after save and reload. (DOC-3109)

## [2.0.2] - 05-Apr-2021
### Added
- Support for the opacity property for annotations. (DOC-2954)
### Fixed
- [Stamp annotations] fixed image stretching issue.
- [Link Annotation] fixed problem with FitR destination.

## [2.0.1] - 10-Mar-2021
### Added
- Added support for Link Annotation. (DOC-2270)
### Fixed
- Required property is missing for TextField form after saving and reloading. (DOC-2808)
- Missing contents property of the RedactAnnotation after save and reload. (DOC-2806)
- The sound annotation doesn't show the file size in Collaboration mode. (DOC-2416)
- The FileAttachment annotation doesn't show the file size in Collaboration. (DOC-2414)

## [1.2.10] - 05-Feb-2021
### Added
- Added support for GcPdfViewer v.4.1  

## [1.2.9] - 15-Jan-2021
### Fixed
- Rotation issue when saving a Pdf. (DOC-2681)

## [1.2.8] - 12-Dec-2020
### Fixed
- Fixed problem with saving file attachments.

## [1.2.7] - 04-Dec-2020
### Added
- Added localization strings for error messages, see ErrorMessages / ErrorMessages_Ja.

## [1.2.6] - 16-Nov-2020
### Fixed
- [Collaboration] Fixed problem with automatic client reconnection. (DOC-2571)

## [1.2.5] - 16-Nov-2020
### Fixed
- Fixed exception when SupportApi is used in self-hosted OWIN application.

## [1.2.4] - 10-Nov-2020
### Fixed
- [Collaboration] Fixed problem with large attachments (DOC-2416/DOC-2414)

## [1.2.3] - 04-Nov-2020
### Fixed
- [Collaboration] The users list who have access to document is incorrect after restart the server. (DOCXLS-3243)
- [Collaboration] Previous access information is displayed for new documents. (DOC-2402)
- [Collaboration] Insert blank page in Collaboration mode doesn't real-time co-authoring. (DOC-2410)

## [1.2.2] - 27-Oct-2020
### Added
- Support token-based authentication. (DOC-2432)
### Fixed
- non-checked RadioButton is not converted to content. (DOC-2376)

## [1.2.1] - 28-Sep-2020
### Added
- Added ability to convert annotations and fields to content. (DOC-1883)
- Collaboration mode feature. (DOC-1595)

## [1.1.26] - 02-Sep-2020
### Fixed
- "incorrect document structure change" after deleting and adding a new page. (DOC-2299)

## [1.1.25] - 24-Aug-2020
### Fixed
- Fixed exception "Failed to compare two elements in the array". (DOC-2272)
- Modified ink annotation retains old ink lists after saving document with SupportApi. (DOC-2283)

## [1.1.24] - 31-July-2020
### Fixed
- On applying redact for two part of scanned page, the saved page has no content. (DOC-2254)

## [1.1.23] - 11-July-2020
### Added
- RadioButtonField: added support for radiosInUnison property. (DOC-2205)

## [1.1.23] - 11-July-2020
### Added
- FreeTextAnnotation: Added a default value for the LineDashPattern property when the border style is set to dashed, but lineDashPattern is not sent from the client viewer.

## [1.1.22] - 30-June-2020
### Added
- Added support for markup annotation references, State and StateModel properties.

## [1.0.12] - 29-June-2020
### Fixed
- The fields order is changed after modifying the name of a radio button in form editor mode. (DOC-2081)
- Cannot save empty text alignment.

## [1.0.11] - 11-June-2020
### Fixed
- Cannot rename radio button field to an existing name to create a radio button group (case 2). (DOC-2025)

## [1.0.10] - 28-May-2020
### Added
- Added new properties: fileUrl, fileName. Sample usage in a controller derived from GcPdfViewerController:
```csharp
public override void OnDocumentModified(GcPdfDocumentLoader documentLoader) {
  string fileUrl = documentLoader.Info.documentOptions.fileUrl;
  string fileName = documentLoader.Info.documentOptions.fileName;
}
```

## [1.0.9] - 09-May-2020
### Fixed
- Incorrect file extension when downloading file using the "save" button in IE11. (DOC-2009)

## [1.0.8] - 08-May-2020
- FreeText annotation's text box size is incorrect when annotation
  updated using Annotation Editor in some cases. (DOC-1990)

## [1.0.7] - 05-May-2020
- All form controls get named with "_1" at end and can't remove it. (DOC-2001)

## [1.0.6] - 04-May-2020
### Fixed
- Adding a field with a duplicate name to a form shows an "Unknown Widget" when loading that form into the viewer. (DOC-1991)
- Deleting a form field could delete just the widget, leaving the field. (DOC-1991)
- Form field changes not saved when field owner is another field. (DOC-1997)
- Forecolor applies on border as well. (DOC-1963)
- Display error message when GcPdf is not licensed. (DOC-1818)

## [1.0.5] - 24-Apr-2020
### Added
- Added support for userData option (Arbitrary data associated with the viewer).
  Sample usage in a controller derived from GcPdfViewerController:
```csharp
  public override void OnDocumentModified(GcPdfDocumentLoader documentLoader) {
    object userData = documentLoader.Info.documentOptions.userData;
  }
```

## [1.0.4] - 22-Apr-2020
### Added
- Added the ability to open a PDF from an external URL.
### Fixed
- Fixed a problem when opening documents without meta information.
- Incorrect rendering of redact annotations in some PDFs. (DOC-1976)
- Fixed a problem with updating form fields tab order. (DOC-1982)

## [1.0.3] - 09-Apr-2020
### Fixed
- Viewer pops up an error message when opening a password-protected file. (DOC-1946)

## [1.0.2] - 02-Apr-2020
### Added
- Added support for WebForm applications.
- Display 'Document is too large' message when document exceeds request size allowed by HTTP server.
### Fixed
- Fixed a thread safety problem when SupportApi is used to open several documents at once.
- Text justification does not applied to a text field widget when modified document is saved and loaded into viewer again. (DOC-1873)
- Fixed problem with resolving Download action for Web Api 2 (Web Forms) routing.
- Fixed problem with converting line annotation's coordinate values for some specific cultures.

## [1.0.1] - 10-Mar-2020
### Added
- Added ability to edit basic Link annotation properties. (DOC-1847)
- Version number (Properties/AssemblyInfo.cs) (1.0.1).
- CHANGELOG.md (this file).

## [1.0.0] - 05-Mar-2020
### First public release.
