﻿using System;
using GrapeCity.Documents.Pdf;
using GrapeCity.Documents.Pdf.AcroForms;
using GrapeCity.Documents.Pdf.Security;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Models
{

    /// <summary>
    /// Information about document signature sent from client.
    /// </summary>
    public class SignatureInfo
    {
        /// <summary>
        /// Gets or sets the information provided by the signer to enable a recipient to contact the signer
        /// to verify the signature (for example, a phone number).
        /// </summary>
        public string contactInfo { get; set; }

        /// <summary>
        /// Gets or sets the CPU host name or physical location of the signing.
        /// <para>
        /// By default this property is initalized with <see cref="Environment.MachineName"/>.
        /// </para>
        /// </summary>
        public string location { get; set; }

        /// <summary>
        /// Gets or sets the name of the person or authority signing the document.
        /// <para>
        /// NOTE: This value is used only if it is not possible to extract the name from the signature,
        /// for example from the certificate of the signer.
        /// </para>
        /// <para>
        /// By default this property is initialized with <see cref="Environment.UserName"/>.
        /// </para>
        /// </summary>
        public string signerName { get; set; }

        /// <summary>
        /// Gets or sets the reason for the signing, such as "I agree...".
        /// </summary>
        public string reason { get; set; }

        /// <summary>
        /// Gets or sets an signature field name used to store a digital signature.
        /// </summary>
        public string signatureField { get; set; }


        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as SignatureInfo);
        }

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="signatureInfo"></param>
        /// <returns></returns>
        public bool Equals(SignatureInfo signatureInfo)
        {
            return signatureInfo != null &&
                   contactInfo == signatureInfo.contactInfo && location == signatureInfo.location &&
                signerName == signatureInfo.signerName
                && reason == signatureInfo.reason
                && signatureField == signatureInfo.signatureField;
        }

    }
}
