﻿using System;
using System.Security.Cryptography.X509Certificates;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;

#if WEB_FORMS
using System.Web.Http.Controllers;
#else
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Crypto.Tls;
#endif

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Models
{
    /// <summary>
    /// Represents arguments for the event that is fired when the document is about to be signed.
    /// </summary>
    /// <example>
    ///   // Implement PDF document signing
    ///   
    ///   public void Configuration(IAppBuilder app) {
    ///     // ... Rest configuration code
    ///     GcPdfViewerController.Settings.Sign += _OnSign;
    ///   }
    ///
    ///   private void _OnSign(object sender, SignEventArgs e)
    ///   {
    ///       var signatureProperties = e.SignatureProperties;
    ///       X509Certificate2 certificate = new X509Certificate2(System.IO.File.ReadAllBytes("Test.pfx"), "password", 
    ///                                                           X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
    ///       signatureProperties.SignatureBuilder = new Pkcs7SignatureBuilder()
    ///       {
    ///          CertificateChain = new X509Certificate2[] { certificate },
    ///          HashAlgorithm = Security.OID.HashAlgorithms.SHA512,
    ///          Format = Pkcs7SignatureBuilder.SignatureFormat.adbe_pkcs7_detached
    ///       };
    ///   }
    /// </example>
    public class SignEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SignEventArgs"/> class.
        /// </summary>
        /// <param name="signatureProperties"></param>
        /// <param name="document"></param>
        public SignEventArgs(SignatureProperties signatureProperties, GcPdfDocument document) : base()      
        {
            SignatureProperties = signatureProperties;
            Document = document;
            Reject = false;            
        }

        /// <summary>
        /// Gets the SignatureProperties which will be used to sign document.
        /// </summary>
        public SignatureProperties SignatureProperties { get; }

        /// <summary>
        /// Gets the GcPdfDocument which will be signed.
        /// </summary>
        public GcPdfDocument Document { get; }

        /// <summary>
        /// Set the Reject property to true if document signing action need to be rejected.
        /// </summary>
        public bool Reject { get; set; }
    }

}
