﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Models
{

    /// <summary>
    /// Calculated rectangles before and after rotation.
    /// </summary>
    public class RotationRectangleInit
    {
        public int[] initRect { get; set; }

        public int[] rotatedRect { get; set; }

        public int angle { get; set; }

        public float dx { get; set; }

        public float dy { get; set; }

    }
}
