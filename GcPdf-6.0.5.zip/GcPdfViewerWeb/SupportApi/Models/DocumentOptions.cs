﻿using System;
using System.Net.NetworkInformation;
using System.Reflection;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Models
{
    /// <summary>
    /// Client side options and properties which was passed from viewer.
    /// </summary>
    public class DocumentOptions
    {

        /// <summary>
        /// Required. Unique viewer identifier.
        /// </summary>
        public string clientId { get; set; }

        /// <summary>
        /// Optional. The password used to open the document.
        /// </summary>
        public string password;

        /// <summary>
        ///  URL which was used to open document.
        /// </summary>
        public string fileUrl;

        /// <summary>
        /// File name which was used to open document.
        /// </summary>
        public string fileName;

        /// <summary>
        /// The friendly file name option specified on client (see GcPdfViewer's friendlyFileName option).
        /// </summary>
        public string friendlyFileName;

        /**
        * Arbitrary data associated with the viewer.
        * This data is sent to the server when the document is saved.
        **/
        public object userData;

        /// <summary>
        /// Current user name. When specified this value will be used as UserName to mark annotation's state 
        /// and as author name for sticky note's replies.
        /// </summary>
        public string userName;

        /// <summary>
        /// Document save settings.
        /// </summary>
        public SaveSettings saveSettings;

        /// <summary>
        /// Returns key string which can be used to identify document options object.
        /// </summary>
        /// <remarks>
        /// Note about correlationId:
        /// The correlation identifier of the original message which initiates the requests/answers pipeline.
        /// Explanation: the document saving process when two or more concurrency requests executed can be as follow:
        /// 1. SetOptions(); // generate correlationId 1.
        /// 2. Modify(); // uses correlationId 1.
        /// 3. SetOptions(); // generate correlationId 2. (parallel request)
        /// 4. UploadFile(); // uses correlationId 1.
        /// 5. Modify(); // uses correlationId 2. (parallel request)
        /// 6. Save(); // uses correlationId 1.
        /// 7. Save(); // uses correlationId 2. (parallel request)
        /// So, we use the correlationId to identify the request execution pipe.
        /// </remarks>
        /// <returns></returns>
        public static string GetKey(string clientId, string correlationId)
        {
            return $"{clientId}_{correlationId ?? "root"}";
        }


    }

    /// <summary>
    /// Document save settings.
    /// </summary>
    public class SaveSettings
    {

        /// <summary>
        /// Optional.Destination document format.
        /// PDF - the document will be saved in PDF format.
        /// PNG - the document will be saved to images.
        /// Default is PDF.
        /// </summary>
        public string format { get; set; }

        /// <summary>
        /// You can specify the index of the page(s) or pages range to save.
        /// For a range of pages, use a hyphen.Separate page or pages range with a comma, e.g. "0, 1, 4-5, 8".
        /// You can also change the page order: "1, 0, 2-8".
        /// Or clone required pages: "0, 0, 3, 3, 3"
        /// </summary>
        public string pages { get; set; }

        /// <summary>
        /// Optional. Defines the mode of saving a PDF. 
        /// Available values are: "Auto" | "Default" | "Linearized" | "IncrementalUpdate".
        /// Default is null - the PDF is not linearized and the incremental update will be used only for signed PDF documents.
        /// </summary>
        public string saveMode { get; set; }

        /// <summary>
        /// Optional. Save modifications to server without  file to local disk. Default is false;
        /// </summary>
        public bool saveModificationsOnly { get; set; }

        /// <summary>
        /// Optional. Signature settings used to save document with signature. If specified, the document will be saved with signature.
        /// </summary>
        public SignatureInfo sign { get; set; }

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as SaveSettings);
        }

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="saveSettings"></param>
        /// <returns></returns>
        public bool Equals(SaveSettings saveSettings)
        {
            return saveSettings != null &&
                   format == saveSettings.format && pages == saveSettings.pages && saveMode == saveSettings.saveMode
                && saveModificationsOnly == saveSettings.saveModificationsOnly
                && (sign == null && saveSettings.sign == null || sign != null && sign.Equals(saveSettings.sign));
        }

    }
}
