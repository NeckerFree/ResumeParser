﻿using GrapeCity.Documents.Pdf;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Localization;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Models;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Resources.Stamps;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Models
{
    /// <summary>
    /// Support API settings.
    /// </summary>
    public class SupportApiSettings
    {
        /// <summary>
        /// Contains additional options using during redact action.
        /// </summary>
        public RedactOptions RedactOptions { get; set; }

        /// <summary>
        /// Collaboration mode settings.
        /// </summary>
        public CollaborationSettings Collaboration { get; private set; } = new CollaborationSettings();

        /// <summary>
        /// Gets or sets a list of all available user names. These names will be shown in the Share Document dialog box.
        /// </summary>
        public List<string> AvailableUsers { get; private set; } = new List<string>();

        /// <summary>
        /// Localized error messages.
        /// </summary>
        public ErrorMessages ErrorMessages { get; internal set; } = Localizer.GetErrorMessages();

        /// <summary>
        /// Specifies the mode of saving PDFs.
        /// <para>
        /// The default is <see langword="null"/>. In that case PDFs are not linearized, and incremental update will be used only for signed PDFs.
        /// </para>
        /// </summary>
        public SaveMode? SaveMode { get; set; } = null;

        /// <summary>
        /// Stamp images storage.
        /// </summary>
        public IStampImagesStorage StampImagesStorage { get; set; }

        /// <summary>
        /// This event is fired when a client accesses any SupportApi method.
        /// Use this event in order to verify authentication token passed from client.
        /// </summary>
        public event VerifyTokenEventHandler VerifyToken
        {
            // Add the input delegate to the collection.
            add
            {
                verifyTokenEventDelegates.AddHandler(verifyTokenEventKey, value);
            }
            // Remove the input delegate from the collection.
            remove
            {
                verifyTokenEventDelegates.RemoveHandler(verifyTokenEventKey, value);
            }
        }

        /// <summary>
        /// This event is fired when a document is about to be signed.
        /// <para>To sign the document, fill the SignatureProperties property.</para>
        /// <code>
        /// // Example:
        ///   
        /// public void Configuration(IAppBuilder app) {
        ///     GcPdfViewerController.Settings.Sign += _OnSign;
        ///     // ... Rest configuration code
        /// }
        ///
        /// private void _OnSign(object sender, SignEventArgs e)
        /// {
        ///     var signatureProperties = e.SignatureProperties;
        ///     X509Certificate2 certificate = new X509Certificate2(System.IO.File.ReadAllBytes("Test.pfx"), "password", 
        ///         X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
        ///     signatureProperties.SignatureBuilder = new Pkcs7SignatureBuilder()
        ///     {
        ///         CertificateChain = new X509Certificate2[] { certificate },
        ///         HashAlgorithm = Security.OID.HashAlgorithms.SHA512,
        ///         Format = Pkcs7SignatureBuilder.SignatureFormat.adbe_pkcs7_detached
        ///     };
        /// }
        /// </code>
        /// </summary>
        public event SignEventHandler Sign
        {
            // Add the delegate to the collection.
            add
            {
                signEventDelegates.AddHandler(signEventKey, value);
            }
            // Remove the delegate from the collection.
            remove
            {
                signEventDelegates.RemoveHandler(signEventKey, value);
            }
        }

        /// <summary>
        /// Indicates whether the Sign event has any event delegates.
        /// </summary>
        public bool HasSignHandlers
        {
            get
            {
                SignEventHandler eventDelegate = (SignEventHandler)signEventDelegates[signEventKey];
                return eventDelegate != null;
            }
        }

        internal void OnSign(SignEventArgs e)
        {
            SignEventHandler eventDelegate = (SignEventHandler)signEventDelegates[signEventKey];
            if (eventDelegate != null)
            {
                eventDelegate(this, e);
            }
        }

        internal void OnVerifyToken(VerifyTokenEventArgs e)
        {
            VerifyTokenEventHandler eventDelegate = (VerifyTokenEventHandler)verifyTokenEventDelegates[verifyTokenEventKey];
            if (eventDelegate != null)
            {
                eventDelegate(this, e);
            }
        }



        static readonly object signEventKey = new object();
        protected EventHandlerList signEventDelegates = new EventHandlerList();
        static readonly object verifyTokenEventKey = new object();
        protected EventHandlerList verifyTokenEventDelegates = new EventHandlerList();
    }

    /// <summary>
    /// Sign event delegate.
    /// </summary>
    /// <param name="sender">Sender object</param>
    /// <param name="e">SignEventArgs</param>
    public delegate void SignEventHandler(Object sender, SignEventArgs e);

    /// <summary>
    /// Verify token event delegate.
    /// </summary>
    /// <param name="sender">Sender object</param>
    /// <param name="e">VerifyTokenEventArgs</param>
    public delegate void VerifyTokenEventHandler(Object sender, VerifyTokenEventArgs e);    

    
}
