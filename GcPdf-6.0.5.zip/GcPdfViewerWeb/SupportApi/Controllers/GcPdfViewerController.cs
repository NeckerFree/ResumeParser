﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.IO.Compression;
using System.Collections.Generic;
#if WEB_FORMS
using System.Web.Http;
using System.Web.Http.Controllers;
#else
using Microsoft.Extensions.Primitives;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
#endif
using Newtonsoft.Json;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Utils;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Models;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Connection;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Collaboration;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Resources.Stamps;

namespace GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers
{
    /// <summary>
    /// GcPdfViewer Support API controller.
    /// Derive from this class to provide custom functionality.
    /// </summary>
    /// <example>
    /// Configure controller using ASP.NET Core Application Parts:
    /// <code>
    /// public void ConfigureServices(IServiceCollection services)
    /// {
    ///   services.AddMvc().ConfigureApplicationPartManager(apm => 
    ///     apm.ApplicationParts.Add(new AssemblyPart(typeof(GcPdfViewerController).GetTypeInfo().Assembly)));
    ///   ...
    /// }
    /// </code>
    /// </example>
    [Route("SupportApi/GcPdfViewer")]
#if WEB_FORMS
    public partial class GcPdfViewerController : ApiController
#else
    [ApiController]
    [IgnoreAntiforgeryToken]
    [RequestSizeLimit(268435456/*256MB*/)]
    [RequestFormLimits(MultipartBodyLengthLimit = 268435456/*256MB*/, KeyLengthLimit = 268435456, ValueLengthLimit = 268435456, ValueCountLimit = 268435456)]
    public partial class GcPdfViewerController : ControllerBase
#endif
    {
        #region ** fields
        /// <summary></summary>
        protected static ConcurrentDictionary<string, GcPdfDocumentLoader> _docLoaders = new ConcurrentDictionary<string, GcPdfDocumentLoader>();
        /// <summary></summary>
        protected static ConcurrentDictionary<string, DocumentOptions> _docOptions = new ConcurrentDictionary<string, DocumentOptions>();
        /// <summary></summary>
        protected static ConcurrentDictionary<string, DateTime> _docLoaderLastPingTime = new ConcurrentDictionary<string, DateTime>();
        /// <summary></summary>
        protected static string _lastError;
        /// <summary>
        /// CORS proxy client
        /// </summary>
        private readonly HttpClient _corsProxyClient;
        #endregion

        #region ** constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="GcPdfViewerController"/> class.
        /// </summary>
        public GcPdfViewerController()
        {
            _corsProxyClient = new HttpClient(new HttpClientHandler()
            {
                AllowAutoRedirect = false
            });
        }
        #endregion

        #region ** Event handlers

        /// <summary>
        /// This method is called when a client modifications is applied to an open document.
        /// </summary>
        /// <param name="documentLoader">The document loader instance.</param>
        public virtual void OnDocumentModified(GcPdfDocumentLoader documentLoader)
        {

        }

        #endregion

        #region ** properties

        /// <summary>
        /// Gets the document loaders dictionary.
        /// Keys are client ids, values are instances of the <see cref="GcPdfDocumentLoader"/> class.
        /// </summary>
        public static ConcurrentDictionary<string, GcPdfDocumentLoader> DocumentLoaders
        {
            get
            {
                return _docLoaders;
            }
        }

        /// <summary>
        /// Gets the global Support API settings.
        /// </summary>
        public static SupportApiSettings Settings { get; } = new SupportApiSettings();

        #endregion

        #region ** Web API methods

        #region CORS proxy for PDFs from another domain ( ASP .NET Core version )
#if !WEB_FORMS

        private static HttpRequestMessage CreateProxyHttpRequest(HttpContext context, Uri uri)
        {
            var request = context.Request;

            var requestMessage = new HttpRequestMessage();
            var requestMethod = request.Method;
            if (!HttpMethods.IsGet(requestMethod) &&
                !HttpMethods.IsHead(requestMethod) &&
                !HttpMethods.IsDelete(requestMethod) &&
                !HttpMethods.IsTrace(requestMethod))
            {
                var streamContent = new StreamContent(request.Body);
                requestMessage.Content = streamContent;
            }

            // Copy the request headers
            foreach (var header in request.Headers)
            {
                if (!requestMessage.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray()) && requestMessage.Content != null)
                {
                    requestMessage.Content?.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray());
                }
            }

            requestMessage.Headers.Host = uri.Authority;
            requestMessage.RequestUri = uri;
            requestMessage.Method = new HttpMethod(request.Method);

            return requestMessage;
        }

        private static async Task CopyProxyHttpResponse(HttpContext context, HttpResponseMessage responseMessage)
        {
            if (responseMessage == null)
            {
                throw new ArgumentNullException(nameof(responseMessage));
            }

            var response = context.Response;

            response.StatusCode = (int)responseMessage.StatusCode;
            foreach (var header in responseMessage.Headers)
            {
                response.Headers[header.Key] = header.Value.ToArray();
            }

            foreach (var header in responseMessage.Content.Headers)
            {
                response.Headers[header.Key] = header.Value.ToArray();
            }

            // SendAsync removes chunking from the response. This removes the header so it doesn't expect a chunked response.
            response.Headers.Remove("transfer-encoding");

            using (var responseStream = await responseMessage.Content.ReadAsStreamAsync())
            {
                //0x25 0x50 0x44 0x46 then it's most probably a PDF file.                
                await responseStream.CopyToAsync(response.Body, 81920, context.RequestAborted);
            }
        }

        /// <summary>
        /// CORS proxy for PDF documents from another domain.
        /// Usage example, open PDF document from url https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf:
        /// viewer.open("http://localhost:5005/api/pdf-viewer/CorsProxy?url=https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf");
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("CorsProxy")]
        [HttpGet()]
#else
        [HttpGet("CorsProxy")]
#endif
        public async Task<IActionResult> CorsProxy()
        {
            //
            string url = GetQueryValue("url");
            if (string.IsNullOrEmpty(url) || !url.ToLowerInvariant().EndsWith(".pdf"))
            {
                throw new Exception(GcPdfViewerController.Settings.ErrorMessages.CorsProxyCanOnlyProxyPdfDocuments);
            }
            var request = CreateProxyHttpRequest(HttpContext, new Uri(url));
            var response = await _corsProxyClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, HttpContext.RequestAborted);
            await CopyProxyHttpResponse(HttpContext, response);
            return Ok();
        }
#endif
        #endregion

        /// <summary>
        /// Gets the Support API version.
        /// </summary>
        /// <returns>The Support API version string.</returns>
        /// <example>
        /// http://localhost:50016/SupportApi/GcPdfViewer/Version
        /// http://localhost:50016/api/pdf-viewer/version
        /// </example>
#if WEB_FORMS
        [Route("Version")]
        [HttpGet()]
#else
        [HttpGet("Version")]
#endif
        public virtual string Version()
        {
            try
            {
                VerifyTokenInternal(nameof(Version));
                return GetVersion();
            }
            catch (Exception e)
            {
                return $"Error: {e.Message}";
            }
        }

        /// <summary>
        /// Sets the document options.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("SetOptions")]
        public virtual async Task<object> SetOptions()
        {
            string clientID = GetLastParameter();
#else
        [Route("SetOptions/{clientID}")]
        public virtual async Task<object> SetOptions(string clientID)
        {
#endif
            using (var ms = await ReadBodyAsync())
            {
                var lockObj = GetClientLockObject(clientID);
                lock (lockObj)
                {
                    var correlationId = GetQueryValue("correlationId");
                    DocumentOptions documentOptions = null;
                    try
                    {
                        VerifyTokenInternal(nameof(SetOptions));
                        var bytes = ms.ToArray();
                        string json = System.Text.Encoding.UTF8.GetString(bytes);
                        documentOptions = JsonConvert.DeserializeObject<DocumentOptions>(json);
                        if (documentOptions == null || string.IsNullOrEmpty(documentOptions.clientId))
                        {
                            throw new Exception(GcPdfViewerController.Settings.ErrorMessages.CantParseDocumentOptions);
                        }
                        string optsId = DocumentOptions.GetKey(documentOptions.clientId, correlationId);
                        if (_docOptions.ContainsKey(optsId))
                            _docOptions.TryRemove(optsId, out var val);
                        _docOptions.TryAdd(optsId, documentOptions);
                        return _PrepareStringAnswer("ok");
                    }
                    catch (Exception ex)
                    {
                        return _PrepareStringAnswer($"Error: {ex.Message}");
                    }
                }
            }

        }

        /// <summary>
        /// Opens a PDF document using binary data.
        /// </summary>
        /// <returns>Information about the opened document</returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("OpenBinary")]
        public virtual async Task<object> OpenBinary()
        {
            string clientId = GetLastParameter();
#else
        [Route("OpenBinary/{clientId}")]
        public virtual async Task<object> OpenBinary(string clientId)
        {
#endif
            VerifyTokenInternal(nameof(OpenBinary));
            MemoryStream ms = await ReadBodyAsync();
            var lockObj = GetClientLockObject(clientId);
            lock (lockObj)
            {
                SharedAccessMode sharedAccessMode = SharedAccessMode.ViewAndEdit;
                string knownDocumentId = null;
                var connection = ClientConnection.GetByClientId(clientId);
                if (connection != null)
                    knownDocumentId = connection.DocumentId;
                var loader = CreateDocumentLoader(clientId, sharedAccessMode, ms, knownDocumentId);
                return _PrepareJsonAnswer(loader.Info);
            }
        }

        /// <summary>
        /// Verifies a signature field.
        /// The signature is considered valid if the document has not been modified
        /// after the signature was applied.
        /// </summary>
        /// <param name="clientID">The client id.</param>
        /// <param name="fieldName">The signature field name</param>
        /// <returns><see langword="true"/> if the signature was successfully verified, <see langword="false"/> otherwise.</returns>
#if WEB_FORMS
        [Route("VerifySignature")]
        [HttpPost]
        public virtual bool VerifySignature()
        {
            string clientID = GetLastParameter(2);
            string fieldName = GetLastParameter(1);
#else
        [Route("VerifySignature/{clientID}/{fieldName}")]
        public virtual bool VerifySignature(string clientID, string fieldName)
        {
#endif
            VerifyTokenInternal(nameof(VerifySignature));
            fieldName = System.Web.HttpUtility.UrlDecode(fieldName);
            var docLoader = GetDocumentLoader(clientID);
            if (docLoader.VerifySignature(fieldName))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Closes an open document and frees the server resources associated with the document.
        /// </summary>
        /// <param name="clientID">The client id.</param>
        /// <returns>"ok"</returns>
#if WEB_FORMS
        [Route("Close")]
        [HttpPost()]
        public virtual async Task<object> Close()
        {
            string clientID = GetLastParameter();

#else
        [Route("Close/{clientID?}")]
        public virtual async Task<object> Close(string clientID)
        {
#endif
            using (var ms = await ReadBodyAsync())
            {
                if (string.IsNullOrEmpty(clientID))
                {
                    var bytes = ms.ToArray();
                    clientID = System.Text.Encoding.UTF8.GetString(bytes);
                }
                if (!string.IsNullOrEmpty(clientID))
                {
                    DisposeDocumentLoader(clientID);
                    return _PrepareStringAnswer("ok");
                }
                return _PrepareStringAnswer("not found");
            }
        }

        /// <summary>
        /// Accepts a ping from the client viewer.
        /// This method should return "ok" if the document with the specified <paramref name="clientId"/>
        /// is currently open on the server.
        /// <para>Note that this method is now deprecated in favor of the <b>Ver</b> method.</para>
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <returns>"ok" or "not-found".</returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("Ping")]
        public virtual string Ping()
        {
            string clientId = GetLastParameter();
#else
        [Route("Ping/{docId?}")]
        public virtual string Ping(string clientId)
        {
#endif
            VerifyTokenInternal(nameof(Ping));
            if (!string.IsNullOrEmpty(clientId) && _docLoaderLastPingTime.ContainsKey(clientId))
            {
                _docLoaderLastPingTime[clientId] = DateTime.Now;
                _DisposeInactiveDocuments();
                return "ok";
            }
            _DisposeInactiveDocuments();
            return "not-found";
        }

        /// <summary>
        /// Applies specified modifications to an open document.
        /// The modifications to apply are passed in the body of the request.
        /// <para>
        /// Note that if the document with the specified id could not be found on the server,
        /// an error message containing the magic string "Code-N5001" is returned.
        /// If the client viewer sees that string in the return, it opens the document
        /// and repeats the request.
        /// </para>
        /// </summary>
        /// <param name="clientID">The client id.</param>
        /// <returns>"ok" if modifications were applied, an error message otherwise.</returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("Modify")]
        public virtual async Task<object> Modify()
        {
            string clientID = GetLastParameter();
#else
        [Route("Modify/{clientID}")]
        public virtual async Task<object> Modify(string clientID)
        {
#endif
            VerifyTokenInternal(nameof(Modify));
            using (var ms = await ReadBodyAsync())
            {
                var lockObj = GetClientLockObject(clientID);
                lock (lockObj)
                {
                    DocumentModifications modifications = null;
                    try
                    {
                        var bytes = ms.ToArray();
                        string json = System.Text.Encoding.UTF8.GetString(bytes);
                        modifications = JsonConvert.DeserializeObject<DocumentModifications>(json);
                        if (modifications == null)
                        {
                            throw new Exception(Settings.ErrorMessages.CantParseDocumenModifications);
                        }

                    }
                    catch (Exception ex)
                    {
                        return _PrepareStringAnswer($"Error: {ex.Message}");
                    }
                    try
                    {
                        string correlationId = GetQueryValue("correlationId");
                        var docLoader = GetDocumentLoader(clientID);
                        docLoader.ApplyDocumentModifications(modifications, correlationId);
                        OnDocumentModified(docLoader);
                        var docOptions = GcPdfViewerController.FindDocumentOptions(clientID, correlationId);
                        if (docOptions != null && docOptions.saveSettings != null && docOptions.saveSettings.sign != null)
                        {
                            if (!Settings.HasSignHandlers)
                            {
                                throw new Exception(Settings.ErrorMessages.DocumentSigningNotHandled);
                            }
                        }

                        return _PrepareStringAnswer("ok");
                    }
                    catch (NotLicensedException ex)
                    {
                        return _PrepareStringAnswer(ex.Message);
                    }
                    catch (DocumentLoaderNotFoundException ex)
                    {
                        // Document is not open on the server.
                        // "Code-N5001" in the error text tells the client that the document
                        // needs to be re-opened.
                        return _PrepareStringAnswer($"Error: Code-N5001 {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        return _PrepareStringAnswer(ex.Message);
                    }
                }
            }
        }

        /// <summary>
        /// Ensures that the document loader exists on the server.
        /// (The document Loader may not be present after a server restart.)
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("CheckDocumentLoader")]
#else
        [Route("CheckDocumentLoader")]
#endif
        public virtual object CheckDocumentLoader()
        {
            try
            {
                VerifyTokenInternal(nameof(CheckDocumentLoader));
                var clientId = GetQueryValue("clientId");
                GetDocumentLoader(clientId);
                return _PrepareStringAnswer("ok");
            }
            catch (DocumentLoaderNotFoundException ex)
            {
                return _PrepareStringAnswer($"Code-N5001: {ex.Message}");
            }
            catch (Exception ex)
            {
                SetLastError(ex.Message);
                return _PrepareStringAnswer($"Error: {ex.Message}");
            }
        }

        /// <summary>
        /// Downloads a file.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [HttpGet()]
        [Route("DownloadFile")]
#else
        [HttpGet("DownloadFile")]
#endif
        public virtual async Task<object> DownloadFile()
        {
            VerifyTokenInternal(nameof(DownloadFile));
            string clientId = GetQueryValue("clientId");
            string fileId = GetQueryValue("fileId");
            int packageIndex = int.Parse(GetQueryValue("packageIndex"));
            int packagesCount = int.Parse(GetQueryValue("packagesCount"));
            string contentType = GetQueryValue("contentType");
            using (var ms = await ReadBodyAsync())
            {
                try
                {
                    var lockObj = GetClientLockObject(clientId);
                    lock (lockObj)
                    {
                        var docLoader = GetDocumentLoader(clientId);
                        var sharedDoc = SharedDocumentsStorage.Instance().Get(docLoader.DocumentId);
                        if (sharedDoc != null)
                        {
                            byte[] resultBytes = sharedDoc.GetAttachedFile(fileId);
                            return _PrepareFileAttachmentAnswer(new MemoryStream(resultBytes), fileId);
                        }
                        return null;
                    }
                }
                catch (DocumentLoaderNotFoundException ex)
                {
                    // this case is not expected, the document loader 
                    // should already be checked with the CheckDocumentLoader method
                    SetLastError(ex.Message);
                    return _PrepareStringAnswer($"Code-N5001: {ex.Message}");
                }
                catch (Exception ex)
                {
                    SetLastError(ex.Message);
                    return _PrepareStringAnswer($"Error: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Uploads a file.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("UploadFile")]
#else
        [HttpPost("UploadFile")]
#endif
        public virtual async Task<object> UploadFile()
        {
            VerifyTokenInternal(nameof(UploadFile));
            string clientId = GetQueryValue("clientId");
            string fileId = GetQueryValue("fileId");
            int packageIndex = int.Parse(GetQueryValue("packageIndex"));
            int packagesCount = int.Parse(GetQueryValue("packagesCount"));
            string contentType = GetQueryValue("contentType");
            using (var ms = await ReadBodyAsync())
            {
                try
                {
                    var docLoader = GetDocumentLoader(clientId);
                    var bytes = ms.ToArray();
                    byte[] resultBytes;
                    if (contentType == "base64")
                    {
                        string base64Content = System.Text.Encoding.UTF8.GetString(bytes);
                        resultBytes = Convert.FromBase64String(base64Content);
                    }
                    else
                    {
                        resultBytes = bytes;
                    }
                    if (docLoader.AttachedFiles.ContainsKey(fileId))
                    {
                        if (!docLoader.AttachedFiles.TryRemove(fileId, out _))
                        {
                            return _PrepareStringAnswer($"Cannot remove old file data from concurrent dictionary.");
                        }
                    }
                    if (!docLoader.AttachedFiles.TryAdd(fileId, resultBytes))
                    {
                        return _PrepareStringAnswer($"Cannot add file data to concurrent dictionary.");
                    }
                    var sharedDoc = SharedDocumentsStorage.Instance().Get(docLoader.DocumentId);
                    if (sharedDoc != null)
                    {
                        sharedDoc.SetAttachedFile(fileId, resultBytes);
                    }
                    return _PrepareStringAnswer("ok");
                }
                catch (DocumentLoaderNotFoundException ex)
                {
                    // this case is not expected, the document loader 
                    // should already be checked with the CheckDocumentLoader method
                    SetLastError(ex.Message);
                    return _PrepareStringAnswer($"Code-N5001: {ex.Message}");
                }
                catch (Exception ex)
                {
                    SetLastError(ex.Message);
                    return _PrepareStringAnswer($"Error: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Discards all modifications made to a document.
        /// </summary>
        /// <param name="clientID">The client id.</param>
        /// <returns>"ok".</returns>
#if WEB_FORMS
        [HttpPost()]
        [Route("Reset")]
        public virtual object Reset()
        {
            string clientID = GetLastParameter();
#else
        [Route("Reset/{clientID}")]
        public virtual object Reset(string clientID)
        {
#endif
            VerifyTokenInternal(nameof(Reset));
            var docLoader = GetDocumentLoader(clientID);
            docLoader.Reset();
            return _PrepareStringAnswer("ok");
        }

        /// <summary>
        /// Applies modifications and downloads the PDF document as a file.
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <param name="fileName">The file name.</param>
        /// <returns></returns>
#if WEB_FORMS
        [Route("Download")]
        [HttpGet]
        public virtual object Download()
        {
            string clientId = GetLastParameter(2);
            string fileName = GetLastParameter(1);
#else
        [HttpGet("Download/{clientID}/{fileName}")]
        public virtual object Download(string clientId, string fileName)
        {
#endif
            VerifyTokenInternal(nameof(Download));
			fileName = fileName.Base64ToUtf8();
			var docLoader = GetDocumentLoader(clientId);
            string format = GetQueryValue("format");
            string correlationId = GetQueryValue("correlationId");
            if (format == "PNG")
            {
#if WEB_FORMS
                return SaveAsImages();
#else
                return SaveAsImages(clientId, fileName);
#endif
            }
            var lockObj = GetClientLockObject(clientId);
            lock (lockObj)
            {
                var content = new MemoryStream();
                try
                {
                    docLoader.Save(content, correlationId);
                }
                catch (Exception ex)
                {
                    SetLastError(ex.Message);
                }
                fileName = string.IsNullOrEmpty(fileName) ? $"{docLoader.ClientId}.pdf" : fileName;
                if (fileName.EndsWith("-pdf"))
                {
                    fileName = $"{fileName.Substring(0, fileName.Length - "-pdf".Length)}.pdf";
                }
                string ua = GetHeaderValue("User-Agent");
                if (ua.Contains("MSIE") || ua.Contains("Trident"))
                {
                    // IE 11 and lower.
                    // Remove non-asc2 characters, fix DOC-1834 [IE browser]The format of saved file is incorrect:
                    fileName = Regex.Replace(fileName, @"[^\u0000-\u007F]+", string.Empty);
                }

                return _PrepareFileAttachmentAnswer(content, fileName);
            }
        }

        /// <summary>
        /// Generates the file name of a page image.
        /// <para>This method is used by the SaveAsImages method.</para>
        /// </summary>
        /// <param name="pageIndex">Zero-based page index.</param>
        /// <param name="pdfName">The PDF file name without extension.</param>
        /// <returns></returns>
        public virtual string GetImageFileName(int pageIndex, string pdfName)
        {
            return $"{pdfName}-page{pageIndex + 1}.png";
        }

        /// <summary>
        /// Gets a non-empty file name without extension.
        /// <para>This method is used by the SaveAsImages method.</para>
        /// </summary>
        /// <param name="fileName">The file name.</param>
        /// <param name="clientId">The client id.</param>
        /// <returns></returns>
        public virtual string GetFileNameWithoutExtension(string fileName, string clientId)
        {
            fileName = string.IsNullOrEmpty(fileName) ? $"{clientId}" : fileName;
            var lowcaseFileName = fileName.ToLowerInvariant();
            if (lowcaseFileName.EndsWith("-pdf") || lowcaseFileName.EndsWith("-zip") || lowcaseFileName.EndsWith(".zip") || lowcaseFileName.EndsWith(".pdf"))
                fileName = $"{fileName.Substring(0, fileName.Length - "-pdf".Length)}";
            string ua = GetHeaderValue("User-Agent");
            if (ua.Contains("MSIE") || ua.Contains("Trident"))
            {
                // IE 11 and lower.
                // Remove non-asc2 characters, fix DOC-1834 [IE browser]The format of saved file is incorrect:
                fileName = Regex.Replace(fileName, @"[^\u0000-\u007F]+", string.Empty);
            }
            return fileName;
        }

        /// <summary>
        /// Saves the pages of the current PDF document as PNG images, 
        /// zips the images, and downloads the zip archive.
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <param name="fileName">The file name.</param>
        /// <returns></returns>
#if WEB_FORMS
        [Route("SaveAsImages")]
        [HttpGet]
        public virtual object SaveAsImages()
        {
            string clientId = GetLastParameter(2);
            string fileName = GetLastParameter(1);
#else
        [HttpGet("SaveAsImages/{clientID}/{fileName}")]
        public virtual object SaveAsImages(string clientId, string fileName)
        {
#endif
			VerifyTokenInternal(nameof(SaveAsImages));
			fileName = fileName.Base64ToUtf8();
			var lockObj = GetClientLockObject(clientId);
            lock (lockObj)
            {
                var docLoader = GetDocumentLoader(clientId);

                fileName = GetFileNameWithoutExtension(fileName, docLoader.ClientId);

                var content = new MemoryStream();
                try
                {
                    string correlationId = GetQueryValue("correlationId");
                    var resultImages = docLoader.SaveAsImages(correlationId);
                    using (var archive = new ZipArchive(content, ZipArchiveMode.Create, true))
                    {
                        for (int i = 0; i < resultImages.Count; i++)
                        {
                            string imageFileName = GetImageFileName(i, fileName);
                            var fileInArchive = archive.CreateEntry(imageFileName, CompressionLevel.Optimal);
                            using (var entryStream = fileInArchive.Open())
                            {
                                using (var fileToCompressStream = resultImages[i])
                                {
                                    fileToCompressStream.CopyTo(entryStream);
                                }
                            }
                        }
                    }
                    content.Seek(0, SeekOrigin.Begin);
                }
                catch (Exception ex)
                {
                    SetLastError(ex.Message);
                }

                return _PrepareFileAttachmentAnswer(content, $"{fileName}.zip");
            }
        }

        /// <summary>
        /// Downloads the unmodified version of the document.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("DownloadUnmodified")]
        [HttpGet]
        public virtual object DownloadUnmodified()
        {
            string clientId = GetLastParameter(2);
            string fileName = GetLastParameter(1);
#else
        [HttpGet("DownloadUnmodified/{clientId}/{fileName}")]
        public virtual object DownloadUnmodified(string clientId, string fileName)
        {
#endif
            VerifyTokenInternal(nameof(DownloadUnmodified));
			fileName = fileName.Base64ToUtf8();
			MemoryStream content;
            /*
            ClientConnection clientConnection = ClientConnection.GetByClientId(clientId);
            if(clientConnection != null)
            {

            }*/
            var docLoader = GetDocumentLoader(clientId);
            content = new MemoryStream();
            docLoader.SaveWithoutModifications(content, fileName);
            fileName = string.IsNullOrEmpty(fileName) ? $"{docLoader.ClientId}.pdf" : fileName;
            if (fileName.EndsWith("-pdf"))
            {
                fileName = $"{fileName.Substring(0, fileName.Length - "-pdf".Length)}.pdf";
            }
            fileName = Regex.Replace(fileName, @"[^\u0000-\u007F]+", string.Empty);// Remove non-asc2 characters, fix DOC-1834
            return _PrepareFileAttachmentAnswer(content, fileName);
        }

        /// <summary>
        /// Stamp images storage.
        /// </summary>
        public virtual IStampImagesStorage StampImagesStorage
        {
            get
            {
                if (Settings.StampImagesStorage != null)
                    return Settings.StampImagesStorage;
                return new EmbeddedStampImagesStorage();
            }
        }

        /// <summary>
        /// Gets the available stamp names.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("GetStampCategories")]
        [HttpPost]
#else
        [HttpPost("GetStampCategories")]
#endif
        public virtual object GetStampCategories()
        {
            VerifyTokenInternal(nameof(GetStampCategories));
            return _PrepareJsonAnswer(StampImagesStorage.StampCategories);
        }

        /// <summary>
        /// Gets the stamp image.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("GetStampImage")]
        [HttpGet]
        public virtual object GetStampImage()
        {
#else
        [HttpGet("GetStampImage")]
        public virtual object GetStampImage()
        {
#endif
            string categoryId = this.GetQueryValue("categoryId");
            string imageName = this.GetQueryValue("imageName");
            imageName = Regex.Replace(imageName, @"[^\u0000-\u007F]+", string.Empty);// Remove non-asc2 characters, fix DOC-1834
            Stream content = StampImagesStorage.GetStampStream(categoryId, imageName);
            return _PrepareFileAttachmentAnswer(content, imageName);
        }

        /// <summary>
        /// This method is called by the client immediately after an error occurs.
        /// <para>Note that this method is now deprecated in favor of the <b>LastError</b> method.</para>
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("GetLastError")]
        [HttpGet]
#else
        [HttpGet("GetLastError")]
#endif
        public object GetLastError()
        {
            string s = _lastError;
            _lastError = string.Empty;
            return _PrepareStringAnswer(string.IsNullOrEmpty(s) ? "" : s);
        }

        /// <summary>
        /// This method is called by the client immediately after an error occurs.
        /// </summary>
        /// <returns></returns>
#if WEB_FORMS
        [Route("LastError")]
        [HttpPost]
#else
        [HttpPost("LastError")]
#endif
        public object LastError()
        {
            string s = _lastError;
            _lastError = string.Empty;
            return _PrepareStringAnswer(string.IsNullOrEmpty(s) ? "" : s);
        }

        /// <summary>
        /// Gets the Support API version.
        /// </summary>
        /// <returns>The Support API version string.</returns>
        /// <example>
        /// http://localhost:50016/SupportApi/GcPdfViewer/Ver
        /// http://localhost:50016/api/pdf-viewer/ver
        /// </example>
#if WEB_FORMS
        [Route("Ver")]
        [HttpPost()]
#else
        [HttpPost("Ver")]
#endif
        public virtual string Ver()
        {
            VerifyTokenInternal(nameof(Ver));
            return GetVersion();
        }

        #endregion

        #region ** Protected

        private static Dictionary<string, object> _lockObjectsByClientId = new Dictionary<string, object>();

        /// <summary>
        /// Gets an object used for locking concurrency code execution for a specified client id.
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <returns>The object to use for locking.</returns>
        protected object GetClientLockObject(string clientId)
        {
            if (!_lockObjectsByClientId.ContainsKey(clientId))
            {
                _lockObjectsByClientId[clientId] = new Object();
            }
            var lockObj = _lockObjectsByClientId[clientId];
            return lockObj;
        }

        /// <summary>
        /// Prepares a file attachment HTTP answer.
        /// </summary>
        /// <param name="content">The content.</param>
        /// <param name="fileName">The file name.</param>
        /// <returns>An <b>HttpResponseMessage</b> instance for WebForms projects, a <b>FileStreamResult</b> instance for ASP.NET Core projects.</returns>
        protected object _PrepareFileAttachmentAnswer(Stream content, string fileName)
        {
            fileName = Uri.EscapeDataString(fileName); // DOC-4775, DOC-4934
            if (content == null)
            {
#if !WEB_FORMS
                Response.StatusCode = 404;
#endif
                return null;
            }
#if WEB_FORMS
            return new HttpResponseMessage() { Content = new CustomFileAttachmentContent(content, fileName) };
#else
            /* Make sure attachment's filename is working for IE11:
             * use IE11, compatibility mode for content-disposition value. DOC-2009 */
            string contentDispositionValues = $"attachment;filename=\"{fileName}\"";
            Response.Headers.Add("content-disposition", contentDispositionValues);
            Response.Headers.ContentLength = content.Length;
            return new FileStreamResult(content, "application/octet-stream");
#endif
        }

        /// <summary>
        /// Prepare string HTTP answer.
        /// </summary>
        /// <param name="s">The string to return.</param>
        /// <returns>An <b>HttpResponseMessage</b> instance for WebForms projects, the string itself for ASP.NET Core projects.</returns>
        protected object _PrepareStringAnswer(string s)
        {
#if WEB_FORMS
            return new HttpResponseMessage() { Content = new CustomStringContent(s) };
#else
            return s;
#endif
        }

        /// <summary>
        /// Prepares a JSON object answer.
        /// </summary>
        /// <param name="obj">The object to return.</param>
        /// <returns>An <b>HttpResponseMessage</b> instance for WebForms projects, the object itself for ASP.NET Core projects.</returns>
        protected object _PrepareJsonAnswer(object obj)
        {
#if WEB_FORMS
            return new HttpResponseMessage() { Content = new CustomJsonContent(obj) };
#else
            return obj;
#endif
        }

#if WEB_FORMS
        /// <summary>
        /// Gets a parameter specified by its shift from the end.
        /// </summary>
        /// <param name="shift">The shift.</param>
        /// <returns>The specified parameter.</returns>
        protected string GetLastParameter(int shift = 1)
        {
            var localPathArr = Request.RequestUri.LocalPath.Split('/');
            string last = localPathArr[localPathArr.Length - shift];
            return last;
        }
#endif

        /// <summary>
        /// Creates a memory stream and reads the request body into it.
        /// </summary>
        /// <returns>The newly created memory stream.</returns>
        protected async Task<MemoryStream> ReadBodyAsync()
        {
            try
            {
                var ms = new MemoryStream();
#if WEB_FORMS
                await ControllerContext.Request.Content.CopyToAsync(ms);
#else
                await Request.Body.CopyToAsync(ms);
#endif
                return ms;
            }
            catch (Exception ex)
            {
                SetLastError("Document is too large. " + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Sets the latest SupportApi error, this error will be passed to the client viewer.
        /// </summary>
        /// <param name="s">The error description.</param>
        public static void SetLastError(string s)
        {
            _lastError = s;
        }

        /// <summary>
        /// Finds the document options for the client with a specified client id.
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <param name="correlationId">Message correlation id.</param>
        /// <returns></returns>
        public static DocumentOptions FindDocumentOptions(string clientId, string correlationId)
        {
            var optsId = DocumentOptions.GetKey(clientId, correlationId);
            if (_docOptions.ContainsKey(optsId) && _docOptions.TryGetValue(optsId, out var docOptions))
            {
                return docOptions;
            }
            if (string.IsNullOrEmpty(correlationId))
            {
                var lastDocOptions = _docOptions.Where(opt => opt.Key.StartsWith(clientId)).Select(opts => opts.Value).LastOrDefault();
                return lastDocOptions;
            }
            return null;
        }

        /// <summary>
        /// Creates and opens a document loader instance.
        /// </summary>
        /// <param name="clientId">The client id.</param>
        /// <param name="accessMode">The access mode.</param>
        /// <param name="data">Document data.</param>
        /// <param name="knownDocumentId">Document id, or <see langword="null"/> if unknown.</param>
        /// <param name="knownFileName">File name, or <see langword="null"/> if unknown.</param>
        /// <returns>The newly created document loader instance.</returns>
        public static GcPdfDocumentLoader CreateDocumentLoader(string clientId,
                SharedAccessMode accessMode, Stream data, string knownDocumentId = null, string knownFileName = null)
        {
            DocumentOptions docOptions = FindDocumentOptions(clientId, string.Empty);
            if (docOptions != null)
            {
                if (!string.IsNullOrEmpty(knownFileName) && docOptions.fileName != knownFileName)
                    docOptions = null;
            }
            if (docOptions == null)
            {
                docOptions = new DocumentOptions() { clientId = clientId, fileName = knownFileName, fileUrl = knownFileName };
            }

            var loader = new GcPdfDocumentLoader(Settings, docOptions, accessMode);
            _docLoaders[loader.ClientId] = loader;
            _docLoaderLastPingTime[loader.ClientId] = DateTime.Now;
            if (!string.IsNullOrEmpty(knownDocumentId))
            {
                loader.DocumentId = knownDocumentId;
            }
            loader.Open(data, knownDocumentId, knownFileName);
            return loader;
        }

        /// <summary>
        /// Disposes a document loader instance.
        /// </summary>
        /// <param name="clientID">The client id.</param>
        public static void DisposeDocumentLoader(string clientID)
        {
            if (clientID == null)
                return;
            if (_docLoaderLastPingTime.ContainsKey(clientID))
            {
                _docLoaderLastPingTime.TryRemove(clientID, out _);
            }
            var loader = _docLoaders.ContainsKey(clientID) ? _docLoaders[clientID] : null;
            if (loader == null)
            {
                return;
            }
            loader.Dispose();
            _docLoaders.TryRemove(clientID, out _);
            var keysToRemove = _docOptions.Where(opts => opts.Key.StartsWith(clientID)).Select(p => p.Key).ToArray();
            foreach (var k in keysToRemove)
            {
                _docOptions.TryRemove(k, out _);
            }
        }

        private void _DisposeInactiveDocuments()
        {
            var dt = DateTime.Now.AddMinutes(-10);
            var inactiveClientIDs = _docLoaderLastPingTime.Where(kv => kv.Value < dt).Select(kv => kv.Key).ToArray();
            foreach (var clientId in inactiveClientIDs)
            {
                DisposeDocumentLoader(clientId);
            }
        }

        /// <summary>
        /// Gets an existing document loader instance by the client id.
        /// Throws an exception if the requested document loader could not be found.
        /// </summary>
        /// <param name="clientID">The client id.</param>
        /// <returns>The document loader instance.</returns>
        /// <exception cref="DocumentLoaderNotFoundException"></exception>
        public static GcPdfDocumentLoader GetDocumentLoader(string clientID)
        {
            var loader = _docLoaders.ContainsKey(clientID) ? _docLoaders[clientID] : null;
            if (loader == null)
            {
                throw new DocumentLoaderNotFoundException(string.Format("Document loader for client with id {0} not found.", clientID));
            }
            return loader;
        }

        #endregion

        #region ** private

        /**
         * Returns SupportApi/GcPdf version string.
         **/
        protected virtual string GetVersion()
        {
            string supportApiVer = ReflectionUtils.GetInformationalVersion(typeof(GcPdfViewerController).Assembly, 4);
            string gcPdfVer = ReflectionUtils.GetInformationalVersion(typeof(GcPdfDocument).Assembly, 4);
            if (supportApiVer.Equals(gcPdfVer))
                return $"SupportApi/GcPdf v{gcPdfVer}";
            else
                return $"SupportApi v{supportApiVer}/GcPdf v{gcPdfVer}";
        }

        /// <summary>
        /// Get request header value.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetHeaderValue(string key)
        {
            if (string.IsNullOrEmpty(key))
                return "";
            try
            {
#if WEB_FORMS
                var request = ControllerContext.Request;
                if (request.Headers.Contains(key))
                {
#else
                var request = HttpContext.Request;
                if (request.Headers.ContainsKey(key))
                {
#endif
                    return String.Join(",", request.Headers.FirstOrDefault(h => h.Key == key).Value.ToArray());
                }
            }
            catch (FormatException)
            {
#if DEBUG
                // Incorrect key format.
                throw;
#else
                return "";
#endif

            }
            return "";
        }

        /// <summary>
        /// Get URL query value.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected string GetQueryValue(string key)
        {
            string result = string.Empty;
#if WEB_FORMS
            var val = result = ControllerContext.Request.GetQueryNameValuePairs().Where(q => q.Key == key).FirstOrDefault().Value;
            if (val != null)
                result = val;
#else
            var query = HttpContext.Request.Query;
            if (query.ContainsKey(key) &&
                query.TryGetValue(key, out var resultArr) && resultArr.Count > 0)
                result = resultArr[0];
#endif
            if (!string.IsNullOrEmpty(result))
            {
                result = System.Web.HttpUtility.UrlDecode(result);
            }
            return result;
        }

        private void VerifyTokenInternal(string actionName)
        {
#if WEB_FORMS
            HttpControllerContext controllerContext = ControllerContext;
#else
            ControllerContext controllerContext = ControllerContext;
#endif
            string token = GetQueryValue("token");
            if (!string.IsNullOrEmpty(token))
            {
                var matches = Regex.Matches(token, @"value=""(.*?)""", RegexOptions.Multiline | RegexOptions.IgnoreCase);
                if (matches.Count > 0)
                {
                    Match m = matches[0];
                    if (m.Groups.Count > 1)
                        token = m.Groups[1].Value;
                }
#if WEB_FORMS
                if (!controllerContext.Request.Headers.Contains("RequestVerificationToken"))
                    controllerContext.Request.Headers.Add("RequestVerificationToken", token);
#else
                if (!controllerContext.HttpContext.Request.Headers.ContainsKey("RequestVerificationToken"))
                    controllerContext.HttpContext.Request.Headers.Add("RequestVerificationToken", new StringValues(token));
#endif
            }
            var e = new VerifyTokenEventArgs(controllerContext, token, actionName);
            Settings.OnVerifyToken(e);
            if (e.Reject)
            {
                throw new HttpListenerException(401, GcPdfViewerController.Settings.ErrorMessages.Unauthorized);
            }
        }

        #endregion
    }
}
