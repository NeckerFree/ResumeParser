# [GrapeCity.Documents.Pdf.ViewerSupportApi](https://www.grapecity.com/documents-api-pdf/javascript-pdf-viewer)

The __GrapeCity.Documents.Pdf.ViewerSupportApi__ package implements the server-side **Support API**
for the __GrapeCity Documents PDF Viewer__ (__GcPdfViewer__),
and can be used in ASP.&#8203;NET Core and Web Forms projects.
GcPdfViewer is a JavaScript client-side control that is available on npmjs: https://www.npmjs.com/search?q=gcpdfviewer.
It is a part of the [GrapeCity Documents for PDF](https://www.grapecity.com/documents-api-pdf) product.
GcPdfViewer can be used as a powerful client-side only PDF viewer.
If connected via __Support API__ to a backend running [GcPdf](https://www.nuget.org/packages/GrapeCity.Documents.Pdf/)
on the server, the viewer enables:
  - Customizable and mobile-friendly PDF form filler
  - Real-time collaborative editing mode
  - Annotation and form editors
  - Quick edits using secondary toolbars
  - PDF redaction
  - Signature verification
  - Predefined stamps
  - Other editing features

The full source code of this library together with C# demo projects for ASP.&#8203;NET Core and Web Forms
is included in the __src/__ folder in this package. The **WEB_FORMS** constant is defined for the Web Forms target.

## Resources

- [GcPdfViewer Product Page](https://www.grapecity.com/documents-api-pdf/javascript-pdf-viewer)
- [GcPdfViewer Live Demos](https://www.grapecity.com/documents-api-pdfviewer/demos/)
- [GcPdf Live Demos](https://www.grapecity.com/documents-api-pdf/demos)
- [License Information](https://www.grapecity.com/documents-api-pdf/docs/online/licenseinfo.html)
- [Licensing FAQ](https://www.grapecity.com/licensing/documents-api)
- [How to get Trial Keys](https://www.grapecity.com/documents-api-pdf/docs/online/licenseinfo.html)

## GrapeCity Document APIs

- [Documents for PDF](https://www.grapecity.com/documents-api-pdf)
- [Documents for Word](https://www.grapecity.com/documents-api-word)
- [Documents for Imaging](https://www.grapecity.com/documents-api-imaging)
- [Documents for Excel, .NET](https://www.grapecity.com/documents-api-excel)
- [Documents for Excel, Java](https://www.grapecity.com/documents-api-excel-java)
