﻿using System;
using System.Reflection;
using System.IO;
using System.Linq;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;
using GcPdfViewerSupportApiDemo.Samples;
using Microsoft.AspNetCore.Mvc;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Utils;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using GrapeCity.Documents.Pdf;
using System.Threading.Tasks;

namespace GcPdfViewerSupportApiDemo.Controllers
{
    [Route("api/pdf-viewer")]
    [ApiController]
    public class SampleSupportController : GcPdfViewerController
    {
        static SampleSupportController()
        {
#if DEBUG
            // VS's F5 sets the current working directory to project dir rather than bin dir,
            // we set it to bin dir so that we can fetch files from the Resources/ sub-dir:
            var exePath = new Uri(Assembly.GetEntryAssembly().CodeBase).LocalPath;
            var directory = Path.GetDirectoryName(exePath);
            Directory.SetCurrentDirectory(directory);
#endif
            Settings.AvailableUsers.AddRange(new string[] { "James", "Susan Smith" });
        }

        /// <summary>
        /// Generate the sample PDF.
        /// </summary>
        /// <returns></returns>
        [Route("get-sample-pdf")]
        public virtual IActionResult GetSamplePdf()
        {
            Response.Headers["Content-Disposition"] = $"inline; filename=\"GcPdfViewerDemo.pdf\"";
            var result = new FileStreamResult(SamplePdfCreator.CreatePdf(), "application/pdf");
            return result;
        }

        /// <summary>
        /// The method receives requests from the document list panel,
        /// see DocumentList below.
        /// </summary>
        /// <returns></returns>
        [Route("get-pdf-from-list")]
        public virtual IActionResult GetPdfFromList(string name)
        {
            Response.Headers["Content-Disposition"] = $"inline; filename=\"{name}\"";
            var filePath = Path.Combine("Resources", "PDFs", name);
            return new FileStreamResult(System.IO.File.OpenRead(filePath), "application/pdf");
        }

        /// <summary>
        /// This method is used by the Document List Panel sample.
        /// </summary>
        /// <returns></returns>
        [Route("DocumentList")]
        public object DocumentList()
        {
            var directoryInfo = new DirectoryInfo(Path.Combine("Resources", "PDFs"));
            var allPdfs = directoryInfo.GetFiles("*.pdf");
            return _PrepareJsonAnswer(allPdfs.Select(
                f_ => $"{f_.Name}|api/pdf-viewer/get-pdf-from-list?name={f_.Name}|Open {f_.Name}"));
        }

        /// <summary>
        /// As an example, override one of the base Support API methods.
        /// </summary>
        /// <returns></returns>
        public override string Ping(string docId)
        {
            return base.Ping(docId);
        }

        public override void OnDocumentModified(GcPdfDocumentLoader documentLoader)
        {
            CleanupSampleCloudStorage();
            var userData = documentLoader.Info.documentOptions.userData as JObject;
            if (userData != null)
            {
                var userDataObj = userData.ToObject<Dictionary<string, string>>();
                if (userDataObj != null)
                {
                    if (userDataObj.ContainsKey("sampleName") && userDataObj["sampleName"] == "SaveChangesSample")
                    {
                        string docName = userDataObj["docName"];
                        SaveDocumentToCloud(documentLoader.ClientId, documentLoader.Document, docName);
                    }

                }
            }
        }

        #region ** ViewerSaveChanges sample:

        /// <summary>
        /// This method is called from the client side.
        /// </summary>
        /// <param name="docName"></param>
        /// <param name="clientId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        [Route("GetPdfFromCloud")]
        async public Task<IActionResult> GetPdfFromCloud(string docName, string clientId)
        {
            var fileBytes = await GetDocumentFromCloud(docName, clientId);
            if (fileBytes == null)
                throw new Exception($"Sample document '{docName}' not found.");
            return new FileContentResult(fileBytes, "application/pdf")
            {
                FileDownloadName = docName
            };
        }

        /// <summary>
        /// Save the PDF document to a Cloud Service.
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="document"></param>
        /// <param name="docName"></param>
        public void SaveDocumentToCloud(string clientId, GcPdfDocument document, string docName)
        {
            // ************************************************************************************
            // Write your code to save a PDF document to a specific Cloud Service here.
            // ************************************************************************************

            // Here's the sample stub code:
            SaveToMemory(clientId, document, docName); 
            //SaveToDisk(document, docName);

        }


        /// <summary>
        /// Download a PDF document from a Cloud Service.
        /// </summary>
        /// <param name="docName"></param>
        /// <param name="clientId"></param>
        /// <returns></returns>
        async public static Task<byte[]> GetDocumentFromCloud(string docName, string clientId)
        {
            // ************************************************************************************
            // Write your code to get a PDF document from a specific Cloud Service here.
            // ************************************************************************************

            // Here's the sample stub code:
            return LoadFromMemory(clientId, docName);
            //return LoadFromDisk(docName);
        }

        #region ** disk storage example

        private static byte[] LoadFromDisk(string docName)
        {
            string path = $"Documents/{docName}";
            return System.IO.File.ReadAllBytes(path);
        }

        private void SaveToDisk(GcPdfDocument document, string docName)
        {
            if (!Directory.Exists("Documents"))
                Directory.CreateDirectory("Documents");
            string path = $"Documents/{docName}";
            document.Save(path);
        }

        #endregion

        #region ** in-memory storage example

        public static Dictionary<string, KeyValuePair<DateTime, byte[]>> DocumentsInCloud { get; private set; } = new Dictionary<string, KeyValuePair<DateTime, byte[]>>();

        private static byte[] LoadFromMemory(string clientId, string docName)
        {
            var key = $"{docName}_{clientId}";
            byte[] bytes = null;
            lock (DocumentsInCloud)
            {
                bytes = DocumentsInCloud.ContainsKey(key) ? DocumentsInCloud[key].Value : null;
            }
            CleanupSampleCloudStorage();
            return bytes;
        }

        private void SaveToMemory(string clientId, GcPdfDocument document, string docName)
        {
            var key = $"{docName}_{clientId}";
            MemoryStream ms = new MemoryStream();
            document.Save(ms);
            lock (DocumentsInCloud)
            {
                if (DocumentsInCloud.ContainsKey(key))
                    DocumentsInCloud.Remove(key);
                DocumentsInCloud.Add(key, new KeyValuePair<DateTime, byte[]>(DateTime.Now, ms.ToArray()));
            }
            ms.Dispose();
        }

        static void CleanupSampleCloudStorage()
        {
            lock (DocumentsInCloud)
            {
                foreach (var k in DocumentsInCloud.Keys)
                {
                    if ((DateTime.Now - DocumentsInCloud[k].Key) > new TimeSpan(0, 10, 0) /* 10 min */)
                    {
                        DocumentsInCloud.Remove(k);
                    }
                }
            }
        }

        #endregion


        #endregion

    }
}
