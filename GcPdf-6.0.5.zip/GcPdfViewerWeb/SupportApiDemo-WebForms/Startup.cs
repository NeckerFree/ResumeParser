﻿using Microsoft.Owin;
using Owin;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;

[assembly: OwinStartup(typeof(GcPdfViewerSupportApiDemo.Startup))]
namespace GcPdfViewerSupportApiDemo
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            GrapeCity.Documents.Pdf.ViewerSupportApi.Connection.GcPdfViewerHub.Configure(app);
            GcPdfViewerController.Settings.VerifyToken += VerifyAuthToken;
            
        }

        private void VerifyAuthToken(object sender, GrapeCity.Documents.Pdf.ViewerSupportApi.Models.VerifyTokenEventArgs e)
        {
            string token = e.Token;
            if (string.IsNullOrEmpty(token) || !token.Equals("support-api-demo-token-2021"))
            {
                e.Reject = true;
            }
        }
    }
}
