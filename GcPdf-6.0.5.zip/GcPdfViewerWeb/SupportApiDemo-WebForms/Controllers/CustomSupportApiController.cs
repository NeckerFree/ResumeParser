using GcPdfViewerSupportApiDemo.Samples;
using System;
using System.Reflection;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Controllers;
using GrapeCity.Documents.Pdf.ViewerSupportApi.Utils;

namespace GcPdfViewerSupportApiDemo.Controllers
{

    public class CustomSupportApiController : GcPdfViewerController
    {
        static CustomSupportApiController()
        {
            Settings.AvailableUsers.AddRange(new string[] { "James", "Susan Smith" });
#if DEBUG
            // VS's F5 sets the current working directory to project dir rather than bin dir:
            var exePath = new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath;
            var directory = Path.GetDirectoryName(exePath);
            Directory.SetCurrentDirectory(directory);
#endif
        }

        /// <summary>
        /// Generate the sample PDF.
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        [ActionName("GetSamplePdf")]
        public virtual object GetSamplePdf()
        {
            var result = SamplePdfCreator.CreatePdf();
            return _PrepareFileAttachmentAnswer(result, "GcPdfViewerDemo.pdf");
        }

        /// <summary>
        /// The method receives requests from the document list panel,
        /// see DocumentList method.
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        [ActionName("GetPdfFromList")]
        public virtual object GetPdfFromList(string name)
        {
            var filePath = Path.Combine("Resources", "PDFs", name);
            return _PrepareFileAttachmentAnswer(File.OpenRead(filePath), name);
        }

        /// <summary>
        /// This method is used by the Document List Panel sample.
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        [ActionName("DocumentList")]
        public object DocumentList()
        {
            var directoryInfo = new DirectoryInfo(Path.Combine("Resources", "PDFs"));
            var allPdfs = directoryInfo.GetFiles("*.pdf");
            return _PrepareJsonAnswer(allPdfs.Select(
                f_ => $"{f_.Name}|/CustomSupportApi/GetPdfFromList?name={f_.Name}|Open {f_.Name}"));
        }

        public override void OnDocumentModified(GcPdfDocumentLoader documentLoader)
        {
            var content = new MemoryStream();
            documentLoader.Save(content);
            string fileName = documentLoader.Info.documentOptions.fileName;
            fileName = string.IsNullOrEmpty(fileName) ? $"{documentLoader.ClientId}.pdf" : fileName;
            File.WriteAllBytes(Path.Combine(GetDocumentsFolderPath(), fileName), content.ToArray());

            var userData = documentLoader.Info.documentOptions.userData as Newtonsoft.Json.Linq.JObject;
            if (userData != null)
            {
                var userDataObj = userData.ToObject<Dictionary<string, string>>();
                if (userDataObj != null)
                {
                    if (userDataObj.ContainsKey("sampleName") && userDataObj["sampleName"] == "SaveChangesSample")
                    {
                        string docName = userDataObj["docName"];
                        SaveDocumentToCloud(documentLoader.ClientId, documentLoader.Document, docName);
                    }

                }
            }
        }

        public static string GetDocumentsFolderPath()
        {
            return Path.Combine(HttpContext.Current.Server.MapPath("~"), "Documents");
        }

        #region ** ViewerSaveChanges sample:

        public static Dictionary<string, KeyValuePair<DateTime, byte[]>> DocumentsInCloud { get; private set; } = new Dictionary<string, KeyValuePair<DateTime, byte[]>>();

        [HttpGet()]
        [ActionName("GetPdfFromCloud")]
        public object GetPdfFromCloud(string docName, string clientId)
        {
            var fileBytes = GetDocumentFromCloud(docName, clientId);
            if (fileBytes == null)
                throw new Exception($"Sample document '{docName}' not found.");
            return _PrepareFileAttachmentAnswer(new MemoryStream(fileBytes), docName);
        }

        public void SaveDocumentToCloud(string clientId, GrapeCity.Documents.Pdf.GcPdfDocument document, string docName)
        {
            var key = $"{docName}_{clientId}";
            MemoryStream ms = new MemoryStream();
            document.Save(ms);
            lock (DocumentsInCloud)
            {
                if (DocumentsInCloud.ContainsKey(key))
                {
                    DocumentsInCloud.Remove(key);
                }
                DocumentsInCloud.Add(key, new KeyValuePair<DateTime, byte[]>(DateTime.Now, ms.ToArray()));
            }
            ms.Dispose();
        }


        public static byte[] GetDocumentFromCloud(string docName, string clientId)
        {
            var key = $"{docName}_{clientId}";
            byte[] bytes = null;
            lock (DocumentsInCloud)
            {
                bytes = DocumentsInCloud.ContainsKey(key) ? DocumentsInCloud[key].Value : null;
            }
            CleaunupSampleCloudStorage();
            return bytes;

        }

        static void CleaunupSampleCloudStorage()
        {
            lock (DocumentsInCloud)
            {
                foreach (var k in DocumentsInCloud.Keys)
                {
                    if ((DateTime.Now - DocumentsInCloud[k].Key) > new TimeSpan(0, 10, 0) /* 10 min */)
                    {
                        DocumentsInCloud.Remove(k);
                    }
                }
            }
        }

        #endregion
    }
}
