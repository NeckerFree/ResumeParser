# GrapeCity Documents PDF Viewer

#### [日本語](#japanese)

A full-featured JavaScript PDF viewer and editor that comes with [GrapeCity Documents for PDF](https://www.grapecity.com/documents-api-pdf).

__GrapeCity Documents PDF Viewer__ (__GcDocs PDF Viewer__, __GcPdfViewer__) is a fast, modern JavaScript based PDF viewer and editor that runs in all major browsers.
The viewer can be used as a cross platform solution to view (or modify - see _Support API_ below) PDF documents on Windows, MAC, Linux, iOS and Android devices.
GcPdfViewer is included in [GrapeCity Documents for PDF (GcPdf)](https://www.grapecity.com/documents-api-pdf) - a feature-rich cross-platform PDF API library for .NET Core.

[_Support API_](#support_api) is a server-side NuGet package
[GrapeCity.Documents.Pdf.ViewerSupportApi](https://www.nuget.org/packages/GrapeCity.Documents.Pdf.ViewerSupportApi/)
that allows you to easily set up an ASP.&#8203;NET Core or a Web Forms server that employs GcPdf
to add PDF editing abilities to GcPdfViewer.
When connected to a _Support API_ server, GcPdfViewer becomes a powerful PDF editor that can be used
to edit existing or create new PDF documents, fill and save PDF forms,
remove (redact) sensitive content, add or edit annotations and AcroForm fields, and more.

GcPdfViewer provides a rich client side JavaScript object model, see __docs/index.html__ for the client API documentation.

Product highlights:

- Works in all modern browsers, including Edge, Chrome, FireFox, Opera, Safari
- When connected to _GcPdf_ on the server via _Support API_, provides:
  - Customizable and mobile-friendly form filler
  - Real-time collaboration mode
  - Annotation and form editors
  - Quick edits using secondary toolbars
  - PDF redaction
  - Signature verification
  - Other editing features
- Works with frameworks such as React, Preact, Angular
- Supports form filling; filled forms can be printed or form data can be submitted to the server
- Supports XFA (XML Forms Architecture) forms
- Provides caret for text selection/copy, including vertical and RTL texts
- Includes thumbnails, text search, outline, attachments, articles, layers and structure tags panels
- Allows opening PDF files from local disks
- Supports annotations including text, free text, rich text etc.
- Supports redact annotations (including appearance streams), allows user to hide or show redacts
- Supports sound annotations
- Allows rotating and printing the rotated document
- Supports article threads navigation
- Fully supports file attachments (both attachment annotations and document level attachments)
- Comes with several themes, new custom themes can be added
- Supports external CMaps
- ...and more.

## See it in action

- Go to [GrapeCity Documents for PDF Viewer demos](https://www.grapecity.com/documents-api-pdfviewer/demos/)
  to explore the various features of GcPdfViewer, including features that rely on [_Support API_](#support_api).
  The demo site allows you to modify the demo code and immediately see the effect of your changes.
- The [GrapeCity Documents for PDF API demo site](https://www.grapecity.com/documents-api-pdf/demos/)
  uses GcPdfViewer to display sample PDFs.

## Latest changes

## [4.0.5] - 27-Feb-2023
### Fixed
- In some cases the signer's name is not shown correctly in the viewer. (DOC-5145)
- signatureValue returns incorrect JP text for certain PDFs. (DOC-5136)
- [Demos] Downloaded sample cannot be run correctly. (DOC-5149)
- [Editor] Annotations cannot be placed correctly in specific PDFs. (DOC-5125)
- [Editor] Ink annotations' position are incorrect when zooming in/out. (DOC-5139)
- [Editor] A checkbox is not checked when setting its fieldValue same as the export value. (DOC-5151)
- [Editor] Line coordinates are incorrect when adding a line annotation in a specific PDF. (DOC-5144)
- [Editor] A 'Drag and drop error' message shows when trying to input a property value in some cases. (DOC-5169)
- [Editor] In some scenarios, a checkbox that is checked by code does not show as checked. (DOC-5152)
- [Editor] A checkbox's shown value is not synchronized with its state. (DOC-5113)
- [Editor] For checkboxes with the same name, the checked state shows incorrectly by Acrobat in some cases. (DOC-5155)

## [4.0.4] - 06-Feb-2023
### Added
- [Demos] Added new sample "Prevent editing a signed PDF".
### Fixed
- Filling and saving a signed form invalidates the signature. (DOC-5090)
- Localization of digital signature verification. (DOC-5075)

## [4.0.3] - 20-Jan-2023
### Added
- [Editor] Added property editors for line annotation coordinates.
### Fixed
- [Editor] Modifying 'End Y‘ of a line coordinates causes the 'Start Y' to change. (DOC-5040)
- [Editor] In some cases the size of a checkbox becomes incorrect. (DOC-5042)
- Checkbox widgets with the same name did not work correctly. (DOC-4874)
- Ink highlight is not visible in the viewer. (DOC-5048)
- Cannot redefine Ctrl+P keyboard shortcut. (DOC-5021)
- UpdateAnnotation event is not triggered on switching radio buttons. (DOC-5020)
- When a Japanese text is assigned to a ButtonAppearance.Caption, the text is garbled in the generated PDF. (DOC-5028)
- Japanese texts are garbled in the article panel. (DOC-5038)
- PDF content can be printed using native browser menu even when Print is disabled by the disableFeatures option. (DOC-5035)
- disableFeatures.Print does not hide the Print context menu item. (DOC-5029)
- [Editor] Several issues with Ink, Polyline and Polygon annotations and callout lines. (DOC-5014)
- [Editor] Line annotation in the saved PDF is not shown in Acrobat. (DOC-5014)
- [iOS] Unable to toggle checkbox state on touch devices. (DOC-5010)

## [4.0.1] - 27-Dec-2022
### Added
- Added the ability to override addAnnotation/updateAnnotation method parameters:
```javascript
// Example:
const pageIndex = 0;
// Using overridden methods without pageIndex parameter:
annotation.pageIndex = pageIndex;
await viewer.addAnnotation(annotation);
await viewer.updateAnnotation(annotation);
// Using methods with pageIndex parameter:
await viewer.addAnnotation(pageIndex, annotation);
await viewer.updateAnnotation(pageIndex, annotation);
```
- Added the ability to save PDFs using incremental update or linearized mode. (DOC-4913)
```javascript
// Example: save document using IncrementalUpdate mode.
viewer.save("test.pdf", { saveMode: "IncrementalUpdate" });
```
```javascript
// Example: save document using Linearized mode.
viewer.save("test.pdf", {saveMode: "Linearized"});
```
- Added the ability to load an updated PDF document into the viewer without downloading it to the local system.
```javascript
// Example: Save document and load the saved document into the viewer:
await viewer.save("test.pdf", { reload: true });
```
- Added electronic signature API. (DOC-4951)
```javascript
// Example: Save document with signature:
viewer.save("test.pdf", { sign: { signatureField: "field1", signerName: "John Doe" } } );
```
Example of server side signing:
```csharp
// Example: electronically sign PDFs with a .PFX certificate:
public void Configuration(IAppBuilder app) {
  GcPdfViewerController.Settings.Sign += _OnSign;
  // ... 
}
private void _OnSign(object sender, SignEventArgs e)
{
    var signatureProperties = e.SignatureProperties;
    X509Certificate2 certificate = new X509Certificate2(System.IO.File.ReadAllBytes("certificate.pfx"), "password", 
      X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
    signatureProperties.SignatureBuilder = new Pkcs7SignatureBuilder()
    {
       CertificateChain = new X509Certificate2[] { certificate },
       HashAlgorithm = Security.OID.HashAlgorithms.SHA512,
       Format = Pkcs7SignatureBuilder.SignatureFormat.adbe_pkcs7_detached
    };
}
```
- Added signature checking API. (DOC-4962)
```javascript
 // Example: check whether the current document is signed and show information about the signature:
 var viewer = GcPdfViewer.findControl("#root");
 const signatureInfo = await viewer.getSignatureInfo();
 if(signatureInfo.signed) {
   const signatureValue = signatureInfo.signedByFields[0].signatureValue;
   const signerName = signatureValue.name;
   const location = signatureValue.location;
   const signDate = viewer.pdfStringToDate(signatureValue.modificationDate);
   alert("The document was signed using digital signature. Signed by: " + signerName + ", location: " + location + ", sign date: " + signDate.toString());
 } else {
   alert("The document is not signed.");
 }
```
- [demos] Added new sample "Sign document using digital signature".
### Changed
- Default page view margins changed (added left/right margins).
- Japanese localization resources updated.
- Removed border highlight for article thread beads.\
```javascript
// The following code can be used to revert to the previous article thread beads style:
GcPdfViewer.findControl("#root").addViewAreaStyle(".gc-thread-bead { box-shadow: rgba(255, 232, 0, 0.27) 1px 1px 1px 1px;}");
```
### Fixed
- Support multiple quadrilateral regions for text markup annotations. (DOC-5008)
- Incorrect position when a stamp is pasted with zoom different from 100%. (DOC-5006)
- Incorrect highlight when document contains highlight annotations with multiple areas. (DOC-5003)
- Setting to disable the undo/redo operation using keyboard Ctrl+z/y. (DOC-4932 / DOC-4901)
- Polyline changed after saving current document. (DOC-4942)
- Ink annotation's position changed after save then load if the border width was set. (DOC-4941)
- The size of resizing rectangle around sound annotation changed after invoke setAnnotationBounds(). (DOC-4937)
- Cannot invoke signature tool "afterAdd" event if the tool's location was not set to "BottomRight". (DOC-4948)
- Checkboxes with the same name are checked together. (DOC-4874)
- AutoScroll in Single Page View. (DOC-4959)
- Some annotations are not added correctly. (DOC-4943)
- On performing the Undo operation, only the image gets deleted from the stamp Annotation. (DOC-4686)
- Cannot add annotation to the second page of a specific file. (DOC-4935)
- Incorrect selection rectangle position when the page is zoomed to a specific value. (DOC-5001)
- The toolbar button overlaps zoom input. (DOC-5002)

## [4.0.0] - 06-Dec-2022
### Added
- [Editor] Added support (toolbar items and context menu) for text markup annotations (highlight, underline, strikeout and squiggly). (DOC-4471)
```javascript
// To disable showing text markup context menu:
var viewer = new GcPdfViewer(selector, { 
	textMarkupContextMenu: false
});
// To disable showing the markup color selector:
var viewer = new GcPdfViewer(selector, { 
  textMarkupContextMenu: { colors: [] }
});
// To change text markup context menu colors to "Red" and "Black":
var viewer = new GcPdfViewer(selector, { 
	textMarkupContextMenu: { colors: [{value: "#ff0000", displayName: "Red"}, {value: "#000000", displayName: "Black"}] }
});
```
- [Editor] Added the ability to resize line annotations. (DOC-4705)
- [Editor] [Graphical Signature] Added the ability to position a signature and drag it between pages using the mouse. (DOC-4732, DOC-4740)\
  If the signTool.location option is not specified, the signature tool will now allow the user to drag the signature to the desired location, possibly on a different page.
- Added API documentation for the disableFeatures option. (DOC-3298, DOC-4747)
- Added "Ear" icon for sound annotations.
- Added a "Save current document as images" button to the toolbar. (DOC-4774)
### Changed
- Text, sound and file attachment icons updated to look like Acrobat Reader icons.
- The file and sound annotations are no longer resizable. The resulting annotation size now depends on the selected icon type. (DOC-2373)
- The layout of the "Text" quick editing tools has been updated to include buttons for the new text markup annotations.
### Fixed
- Annotation borders appear different in GcPdfViewer and Acrobat. (DOC-4804)
- Line annotation is not visible in some cases. (DOC-4769)
- [Editor] Incorrect icon is shown when adding several text annotations. (DOC-4856)
- [Editor] When converting annotations to content, some annotation icons are incorrect. (DOC-2373)
- [Editor] Once a stamp annotation is rotated, the image cannot be resized. (DOC-4671)
- [Editor] Can not add a stamp annotation to a rotated document. (DOC-4776)
- [Editor] After rotating an annotation it cannot be resized. (DOC-4664)
- [Editor] Error "operation is not valid due to the current state of the object" occurs when attaching a stamp to a PDF. (DOC-4860)

### See __CHANGELOG.&#8203;md__ for previous release notes.

## Installation

### To install the latest release version:

```sh
npm install @grapecity/gcpdfviewer
```

### To install from the zip archive:

Go to https://www.grapecity.com/download/documents-pdf and follow the directions on that page to get your 30-day evaluation and deployment license key.
The license key will allow you to develop and deploy your application to a test server.
Unzip the viewer distribution files (list below) to an appropriate location accessible from the web page where the viewer will live.

Viewer zip includes the following files:

- README.&#8203;md (this file)
- CHANGELOG.&#8203;md
- gcpdfviewer.js
- gcpdfviewer.worker.js
- package.json
- index.html (sample page)
- Theme files:
  - themes/dark-yellow.css
  - themes/dark-yellow.jscss
  - themes/light-blue.css
  - themes/light-blue.jscss
  - themes/viewer.css
  - themes/viewer.jscss
- Predefined CMap files for Chinese, Japanese, or Korean text output:
  - resource/bcmaps/*.bin
- TypeScript declaration files:
  - typings/*.*

## Documentation

Online documentation is available [here](https://www.grapecity.com/documents-api-pdf/docs/online/grapecitydocumentspdfviewer.html).

## Licensing

GrapeCity Documents PDF Viewer is a commercially licensed product. Please [visit this page](https://www.grapecity.com/licensing/documents-api) for details.

## Getting more help

GrapeCity Documents PDF Viewer is distributed as part of GrapeCity Documents for PDF.
You can ask any questions about the viewer, or report bugs using the
[Documents for PDF public forum](https://www.grapecity.com/forums/documents-pdf).

## More details on using the viewer

### Adding the viewer to an HTML page:

```HTML
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!-- Limit content scaling to ensure that the viewer zooms correctly on mobile devices: -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#000000" />
    <title>GrapeCity Documents PDF Viewer</title>
    <script type="text/javascript" src="lib/gcpdfviewer.js"></script>
    <script>
        function loadPdfViewer(selector) {
            var viewer = new GcPdfViewer(selector,
              {
                /* Specify options here */
                renderInteractiveForms: true
              });
            // Skip the 'report list' panel:
            // viewer.addReportListPanel();
            viewer.addDefaultPanels();
            // Optionally, open a PDF (will only work if this runs from a server):
            viewer.open('HelloWorld.pdf');
            // Change default viewer toolbar:
            viewer.toolbarLayout.viewer.default = ['$navigation', '$split', 'text-selection', 'pan', '$zoom', '$fullscreen',
              'save', 'print', 'rotate', 'view-mode', 'doc-title'];
            viewer.applyToolbarLayout();
        }
    </script>
  </head>
  <body onload="loadPdfViewer('#root')">
    <div id="root"></div>
  </body>
</html>
```

### How to license the viewer:

Set the GcPdfViewer Deployment key to the GcPdfViewer.License property before you create and initialize GcPdfViewer.
This must precede the code that references the js files.

```javascript
  // Add your license
  GcPdfViewer.LicenseKey = 'xxx';
  // Add your code
  const viewer = new GcPdfViewer("#viewer1", { file: 'helloworld.pdf' });
  viewer.addDefaultPanels();
```

### <a id="support_api"></a>Support API

_Support API_ is a server-side library available as NuGet package
[GrapeCity.Documents.Pdf.ViewerSupportApi](https://www.nuget.org/packages/GrapeCity.Documents.Pdf.ViewerSupportApi/).
The full source code of this library together with C# demo projects for ASP.&#8203;NET Core and Web Forms
is included in the __src/__ folder inside the package (the **WEB_FORMS** constant is defined for the Web Forms target).
In your server solution you can either reference the package, or include the source project and reference it instead.

When GcPdfViewer is connected to a Support API server, its editing features are enabled.
The edits done on the client are accumulated, and when the user clicks 'save',
the original PDF and the edits are sent to the server, the edits are applied (using GcPdf),
and the modified PDF is sent back to the client.

To set up a Support API server on your own system and see it in action,
download any of the samples from the [GcPdfViewer demo site](https://www.grapecity.com/documents-api-pdfviewer/demos/)
(e.g. [Edit PDF](https://www.grapecity.com/documents-api-pdfviewer/demos/edit-pdf/purejs)),
and follow the instructions in the readme.&#8203;md included in the downloaded zip.

NOTE that you will need a GrapeCity Documents for PDF Professional license to use Support API in your apps.

### Keyboard shortcuts

#### Viewer mode

- ```Ctrl +``` - zoom in
- ```Ctrl -``` - zoom out
- ```Ctrl 0``` - zoom to 100%
- ```Ctrl 9``` - zoom to window
- ```Ctrl A``` - select all
- ```R``` - rotate clockwise
- ```Shift R``` - rotate counterclockwise
- ```H``` - enable pan tool
- ```S``` - enable selection tool
- ```V``` - enable selection tool
- ```Ctrl O``` - open local PDF
- ```Ctrl F``` - text search
- ```Ctrl P``` - print
- ```Home``` - go to start of line
- ```Ctrl Home``` - go to start of document
- ```Shift Home``` - select  to start of line
- ```Shift Ctrl Home``` - select  to start of document
- ```End``` - go to end of line
- ```Ctrl End``` - go to end of document
- ```Shift End``` - select  to end of line
- ```Shift Ctrl End``` - select to end of document
- ```Left``` - go left
- ```Shift Left``` - select left
- ```Alt Left``` - go back in history
- ```Right``` - go right
- ```Shift Right``` - select right
- ```Alt Right``` - go forward in history
- ```Up``` - go up
- ```Shift Up``` - select up
- ```Down``` - go down
- ```Shift Down``` - select down
- ```PgUp``` - page up
- ```PgDown``` - page down
- ```Shift PgUp``` - select page up
- ```Shift PgDown``` - select page down

#### Editing modes

- ```Delete``` - delete selected annotation/field
- ```Esc``` - unselect annotation/field
- ```Ctrl Z``` - undo
- ```Ctrl Y``` - redo
- ```Ctrl Shift Z``` - redo

### Toolbar items

The default viewer toolbar items layout (items starting with '$' are inherited from the base viewer, other items are PDF viewer specific.):

```
['open', '$navigation', '$split', 'text-selection', 'pan', '$zoom', '$fullscreen', 'rotate', 'view-mode', 'theme-change', 'download', 'print', 'save', 'hide-annotations', 'doc-title', 'doc-properties', 'about']
```

The full list of the PDF-viewer specific toolbar items:

```
'text-selection', 'pan', 'open', 'save', 'download', 'print', 'rotate', 'theme-change', 'doc-title', 'view-mode', 'single-page', 'continuous-view'
```

The full list of base viewer toolbar items:

```
'$navigation' '$refresh', '$history', '$mousemode', '$zoom', '$fullscreen', '$split'
```

You can get default base viewer items by using the getDefaultToolbarItems() method, e.g.:

```javascript
const toolbar: Toolbar = viewer.toolbar;
let buttons = toolbar.getDefaultToolbarItems();
buttons = buttons.filter(b => b !== '$refresh');
```

To specify a custom set of toolbar items, use the toolbarLayout property and applyToolbarLayout() method, e.g.:

```javascript
viewer.toolbarLayout.viewer = {
  default: ["$navigation", 'open', '$split', 'doc-title'],
  fullscreen: ['$fullscreen', '$navigation'],
  mobile: ["$navigation", 'doc-title']
};
viewer.toolbarLayout.annotationEditor = {
  default: ['edit-select', 'save', '$split', 'edit-text'],
  fullscreen: ['$fullscreen', 'edit-select', 'save', '$split', 'edit-text'],
  mobile: ['$navigation']
};
viewer.toolbarLayout.formEditor = {
  default: ['edit-select-field', 'save', '$split', 'edit-widget-tx-field', 'edit-widget-tx-password'],
  fullscreen: ['$fullscreen', 'edit-select-field', 'save', '$split', 'edit-widget-tx-field', 'edit-widget-tx-password'],
  mobile: ['$navigation']
};
viewer.applyToolbarLayout();
```

Here is an example of how to create your own custom toolbar button:

```javascript
const toolbar: Toolbar = viewer.toolbar;
toolbar.addItem({
  key: 'my-custom-button',
  iconCssClass: 'mdi mdi-bike',
  title: 'Custom button',
  enabled: false,
  action: () => {
    alert("Custom toolbar button clicked");
  },
  onUpdate: (args) => ({ enabled: viewer.hasDocument }),
});
viewer.toolbarLayout.viewer.default =  ['$navigation', 'my-custom-button'];
viewer.applyToolbarLayout();
```

### Using the viewer in frameworks such as React, Preact, Angular etc.

Add a reference to the viewer script:
```HTML
<body>
  <script type="text/javascript" src="/lib/gcpdfviewer/gcpdfviewer.js"></script>
  ...
```

Add the placeholder to your App template, e.g.:
```HTML
<section id="pdf"></section>
```

Render the viewer:
```javascript
let viewer = new GcPdfViewer('section#pdf');
viewer.addDefaultPanels();
```

---

# <a id="japanese"></a>GrapeCity PDF ビューワ（日本語版）

__GrapeCity PDF ビューワ__ (__GcPdfViewer__) は、主要なブラウザで動作する、JavaScriptベースのPDFビューワおよびエディタです。Windows、MAC、Linux、iOS、Androidなどのデバイス上でPDFドキュメントを表示 (または編集 - 下記の _サポートAPI_ を参照) するためのクロスプラットフォームソリューションとして使用することができます。
なお、本PDFビューワは、クロスプラットフォーム環境にてPDFを作成・編集できるAPIライブラリ [DioDocs for PDF](https://www.grapecity.co.jp/developer/diodocs/pdf) に付属する製品となります。

[_サポートAPI_](#support_api_ja) は、サーバーサイドのNuGetパッケージ
「[GrapeCity.DioDocs.Pdf.ViewerSupportApi.ja](https://www.nuget.org/packages/GrapeCity.DioDocs.Pdf.ViewerSupportApi.ja/)」で、
GcPdfに接続するサーバーをASP.&#8203;NET CoreまたはWeb Formsにて簡単に構築して、
PDFビューワにエディタ機能を追加できるようにするものです。
_サポートAPI_ サーバーに接続すると、PDFビューワをPDFエディタとして使用し、
PDFの新規作成、既存のPDFの編集、PDFフォームの入力や保存、機密コンテンツの削除（墨消し）、
注釈／フォームフィールドの追加／編集などを行うことができるようになります。

PDFビューワのクライアントAPIの詳細については、[こちら](https://docs.grapecity.com/help/diodocs/pdfviewer/)をご参照ください。

製品の特徴：
- Edge、Chrome、FireFox、Opera、Safariを含むすべての最新ブラウザで動作します
- _サポートAPI_ 経由で _GcPdf_  に接続した場合、以下の機能を提供します：
  - カスタマイズ可能でモバイルフレンドリーなフォームフィラー
  - リアルタイムなコラボレーションモード
  - 注釈とフォームの編集
  - セカンドツールバーを使用したクイック編集
  - PDFコンテンツの墨消し
  - 署名の検証
  - その他の編集機能
- React、Preact、Angular などのフレームワークで動作します
- フォームの入力に対応：記入済みフォームの印刷や、フォームデータのサーバへの送信にも対応しています
- XFA（XML Forms Architecture）フォームに対応しています
- 縦書きテキストや右横書きテキストを含む、テキストの選択/コピーのためのキャレットを提供します
- サムネイル、テキスト検索、ブックマーク、添付ファイル、アーティクル、レイヤー、構造ツリーのパネルが含まれます
- ローカルディスクからPDFファイルを開くことができます
- テキスト、フリーテキスト、リッチテキストなどの注釈に対応しています
- 墨消し注釈（APストリームを含む）に対応し、墨消しの表示・非表示が可能です
- 音声注釈に対応しています
- 文書の回転や、回転させた文書の印刷が可能です
- アーティクルのスレッドナビゲーションに対応しています
- 添付ファイル（添付ファイル注釈と文書レベルの添付ファイルの両方）に完全に対応しています
- 複数のテーマがすでに備わっており、さらに新しいカスタムテーマを追加することも可能です
- 外部のCMapに対応しています
- その他、様々な機能を提供しています

## リリースノート
日本語版として動作を保証しているのは、リリースノートに記載しているバージョンのみとなります。

## [4.0.1] - 2023年2月8日
### 追加
- テキストマークアップ注釈（ハイライト、下線、波状下線、取り消し線）に対応しました。
- ツールバーとコンテキストメニューに、テキストマークアップ注釈（ハイライト、下線、波状下線、取り消し線）のための機能を追加しました。
```javascript
// テキストマークアップ注釈のコンテキストメニューを表示しないようにします。
var viewer = new GcPdfViewer(selector, { 
	textMarkupContextMenu: false
});
// テキストマークアップ注釈のコンテキストメニューに、色の選択メニューを表示しないようにします。
var viewer = new GcPdfViewer(selector, { 
  textMarkupContextMenu: { colors: [] }
});
// テキストマークアップ注釈のコンテキストメニューにて選択できる色を、「赤」と「黒」に変更します。
var viewer = new GcPdfViewer(selector, { 
	textMarkupContextMenu: { colors: [{value: "#ff0000", displayName: "赤"}, {value: "#000000", displayName: "黒"}] }
});
```
- PDF のページを画像として保存する機能を追加しました。
- saveAsImages メソッドを追加しました。現在の PDF ドキュメントのページを PNG 画像として保存し、それらの画像を zip に圧縮してダウンロードします。
 ```javascript
 // 例：
 viewer.saveAsImages('test.zip');
 ```
- ツールバーに「現在のドキュメントを画像として保存」ボタンを追加しました。
- customIcons プロパティにて、PDF ビューワーが使用する SVG 形式のアイコンを変更できるようになりました。
```javascript
// 例：
var viewer = new GcPdfViewer("#root", { 
  customIcons: {
    'open': '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="24" height="24" viewBox="0 0 24 24"><path d="M9.516 14.016q1.875 0 3.188-1.313t1.313-3.188-1.313-3.188-3.188-1.313-3.188 1.313-1.313 3.188 1.313 3.188 3.188 1.313zM15.516 14.016l4.969 4.969-1.5 1.5-4.969-4.969v-0.797l-0.281-0.281q-1.781 1.547-4.219 1.547-2.719 0-4.617-1.875t-1.898-4.594 1.898-4.617 4.617-1.898 4.594 1.898 1.875 4.617q0 0.984-0.469 2.227t-1.078 1.992l0.281 0.281h0.797z"></path></svg>',
    'search': '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="24" height="24" viewBox="0 0 24 24"><path d="M9.516 14.016q1.875 0 3.188-1.313t1.313-3.188-1.313-3.188-3.188-1.313-3.188 1.313-1.313 3.188 1.313 3.188 3.188 1.313zM15.516 14.016l4.969 4.969-1.5 1.5-4.969-4.969v-0.797l-0.281-0.281q-1.781 1.547-4.219 1.547-2.719 0-4.617-1.875t-1.898-4.594 1.898-4.617 4.617-1.898 4.594 1.898 1.875 4.617q0 0.984-0.469 2.227t-1.078 1.992l0.281 0.281h0.797z"></path></svg>'
  }
});
```
- マウスを使用して署名を配置し、ページ間でドラッグ移動できるようになりました。\
  また、signTool.location プロパティが指定されていない場合、署名ツールにより追加される署名を任意の場所（別ページなど）にドラッグ移動できるようになりました。
```javascript
// 以前の動作を維持する方法：
// 例1：
var viewer = new GcPdfViewer("#root", { 
	signTool: {
		location: "BottomRight"
	}
});
// 例2：
viewer.options.signTool = { location: "BottomRight" };
```
- スタンプ注釈をページ間でドラッグ移動できるようになりました。
- Undo ストアの現在の状態を取得できる undoStore プロパティを追加しました。\
  なお、このプロパティは読み取り専用であり、プログラムによるコレクション要素の変更はできないことに注意してください。\
  undoState を変更するには、以下の Undo API を使用します。\
  利用可能な Undo API のプロパティ：hasUndoChanges, hasRedoChanges, undoIndex, undoCount\
  利用可能な Undo API のメソッド：undoChanges(), redoChanges()
```javascript
// 例：
viewer.eventBus.on("undostorechanged", function() {
    console.log("undoState が変更されました。", viewer.undoState);
});
// または：
viewer.eventBus.on("documentchanged", function() {
    console.log("ドキュメントが変更されました。", viewer.undoState);
});
```
- 音声注釈に「耳」アイコンを追加しました。
- 増分更新またはリニアライズして PDF を保存できるようになりました。
```javascript
// 例：IncrementalUpdate モードを使用して、増分更新でドキュメントを保存します。
viewer.save("test.pdf", { saveMode: "IncrementalUpdate" });
```
```javascript
// 例：Linearized モードを使用して、リニアライズしてドキュメントを保存します。
viewer.save("test.pdf", {saveMode: "Linearized"});
```
- 更新した PDF ドキュメントをローカルにダウンロードせずにビューワに再表示（リロード）する機能を追加しました。
```javascript
// 例：ドキュメントを保存し、その保存したドキュメントをビューワに再表示します。
await viewer.save("test.pdf", { reload: true });
```
- 電子署名の API を追加しました。
```javascript
// 例：ドキュメントに署名して保存します。
viewer.save("test.pdf", { sign: { signatureField: "field1", signerName: "John Doe" } } );
```
　　サーバー側での署名の例：
```csharp
// 例：.PFX 証明書で PDF に電子署名を行います。
public void Configuration(IAppBuilder app) {
  GcPdfViewerController.Settings.Sign += _OnSign;
  // ... 
}
private void _OnSign(object sender, SignEventArgs e)
{
    var signatureProperties = e.SignatureProperties;
    X509Certificate2 certificate = new X509Certificate2(System.IO.File.ReadAllBytes("certificate.pfx"), "password", 
      X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
    signatureProperties.SignatureBuilder = new Pkcs7SignatureBuilder()
    {
       CertificateChain = new X509Certificate2[] { certificate },
       HashAlgorithm = Security.OID.HashAlgorithms.SHA512,
       Format = Pkcs7SignatureBuilder.SignatureFormat.adbe_pkcs7_detached
    };
}
```
- 署名情報を取得する API を追加しました。
```javascript
 // 例：現在のドキュメントに署名があるかどうかを確認し、署名に関する情報を表示します。
 var viewer = GcPdfViewer.findControl("#root");
 const signatureInfo = await viewer.getSignatureInfo();
 if(signatureInfo.signed) {
   const signatureValue = signatureInfo.signedByFields[0].signatureValue;
   const signerName = signatureValue.name;
   const location = signatureValue.location;
   const signDate = viewer.pdfStringToDate(signatureValue.modificationDate);
   alert("このドキュメントには署名があります。署名者：" + signerName + "、場所：" + location + "、署名日：" + signDate.toString());
 } else {
   alert("このドキュメントには署名はありません。");
 }
```
- プロパティパネルにて、線注釈のサイズを変更できるようになりました。
- addAnnotation／updateAnnotation メソッドのパラメータをオーバーライドする機能を追加しました。
```javascript
// 例：
const pageIndex = 0;
// pageIndex パラメータを持たないオーバーライドされたメソッドを使用します。
annotation.pageIndex = pageIndex;
await viewer.addAnnotation(annotation);
await viewer.updateAnnotation(annotation);
// pageIndex パラメータを持つメソッドを使用します。
await viewer.addAnnotation(pageIndex, annotation);
await viewer.updateAnnotation(pageIndex, annotation);
```

### 変更
- ページビューのデフォルトの余白を変更（左右の余白を追加）しました。
- アーティクルのスレッドコンテンツの枠線ハイライトを削除しました。
```javascript
// 以下のコードを使用すると、以前のアーティクルのスタイルに戻すことができます。
GcPdfViewer.findControl("#root").addViewAreaStyle(".gc-thread-bead { box-shadow: rgba(255, 232, 0, 0.27) 1px 1px 1px 1px;}");
```
- 付箋／音声／添付ファイル注釈のアイコンを Acrobat Reader のアイコンと同様になるよう変更しました。
- 付箋／音声／添付ファイル注釈は、サイズ変更できなくなりました。注釈のサイズは、選択されたアイコンの種類に依存します。
- 「テキスト」のクイック編集ツールにテキストマークアップ注釈のボタンが追加されました。
- 署名ツールのデフォルトの動作が変更になりました。\
  signTool.location プロパティが指定されていない場合、署名ツールにより追加される署名をマウスを使用して任意の場所に移動できるようになります。

### 不具合の修正
- [[5630529354255](https://developer-tools.zendesk.com/hc/ja/articles/5630529354255)] Windowsのタッチデバイス上で「手のひらツール」が正しく動作しない
- [[5650428545551](https://developer-tools.zendesk.com/hc/ja/articles/5650428545551)] スタンプ注釈を一度回転させると、元の角度に戻してもスタンプ画像のサイズを変更できなくなる
- [[5650450427151](https://developer-tools.zendesk.com/hc/ja/articles/5650450427151)] 回転されたページに署名を追加すると正しい向きにならない
- [[5658427842831](https://developer-tools.zendesk.com/hc/ja/articles/5658427842831)] ２バイト文字を含む名前のPDFを開いて保存すると、２バイト文字を除いた名前になる
- [[5663388780175](https://developer-tools.zendesk.com/hc/ja/articles/5663388780175)] 添付ファイルパネルに添付ファイル注釈以外のファイルが表示される
- [[5663407932431](https://developer-tools.zendesk.com/hc/ja/articles/5663407932431)] 線注釈を水平または垂直にすると表示されなくなる
- [[5728182304271](https://developer-tools.zendesk.com/hc/ja/articles/5728182304271)] 適用済みの墨消しの上に他の注釈を配置したとき、その注釈がPDFに保存されない
- [[5728185724175](https://developer-tools.zendesk.com/hc/ja/articles/5728185724175)] 墨消しの上に配置された注釈をコンテンツに変換すると、ドキュメント保存時にエラーが発生する
- [[6116629704079](https://developer-tools.zendesk.com/hc/ja/articles/6116629704079)] 単一ページ表示状態でブラウザの表示倍率を変更すると、スクロール位置が自動で先頭に戻る
- [[6160006702095](https://developer-tools.zendesk.com/hc/ja/articles/6160006702095)] 特定のPDFにスタンプ注釈を追加してコンテンツに変換すると、保存時にエラーが発生する
- [[6160010153487](https://developer-tools.zendesk.com/hc/ja/articles/6160010153487)] 特定のPDFについて、注釈を正しく追加できない

##### 過去のリリースノートについては、 __CHANGELOG-JP.&#8203;md__ をご参照ください。

## 製品デモ
- [PDFビューワの製品デモ](https://demo.grapecity.com/diodocs/pdfviewer/demos/) では、[_サポートAPI_](#support_api_ja) を使用する編集機能を含め、
  PDFビューワの様々な機能を紹介しています。
  このデモでは、クライアント側のコードを変更し、どのように反映されるか確認することもできます。
- [DioDocs for PDFの製品デモ](https://demo.grapecity.com/diodocs/pdf/) 内のすべてのデモでは、PDFビューワを使用してPDFを表示しています。

## インストール
```sh
npm install @grapecity/gcpdfviewer
```

## 製品ヘルプ
製品ヘルプは[こちら](https://docs.grapecity.com/help/diodocs/pdf/#grapecitydocumentspdfviewer.html)からご覧いただけます。

## ライセンス
GrapeCity PDF ビューワのご利用にはライセンスが必要となります。詳しくはWebサイトの[ライセンス手続き](https://www.grapecity.co.jp/developer/support/license#docapi)ページをご覧ください。

## 製品情報
GrapeCity PDF ビューワは、DioDocs for PDF の一部として提供しております。製品に関する詳細な情報については、Webサイトの[製品情報](https://www.grapecity.co.jp/developer/diodocs/pdf)ページをご参照ください。

## PDFビューワの詳細な使用方法
### HTMLページへのPDFビューワの追加
```HTML
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <!--コンテンツの拡大縮小を制限して、モバイルデバイスでビューワが正しくズームできるようにします。-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#000000" />
    <title>GrapeCity PDF ビューワ</title>
    <script type="text/javascript" src="lib/node_modules/@grapecity/gcpdfviewer/gcpdfviewer.js"></script>
    <script>
        function loadPdfViewer(selector) {
            var viewer = new GcPdfViewer(selector,
                {
                    /* ここでオプションを指定します */
                    renderInteractiveForms: true
                });
            viewer.addDefaultPanels();
            // 必要に応じてPDFを開きます（サーバーから実行時にのみ機能）
            viewer.open('HelloWorld.pdf');
            // デフォルトのビューワのツールバーを変更します
            viewer.toolbarLayout.viewer.default = ['$navigation', '$split', 'text-selection', 'pan', '$zoom', '$fullscreen',
                'save', 'print', 'rotate', 'view-mode', 'doc-title'];
            viewer.applyToolbarLayout();
        }
    </script>
</head>
<body onload="loadPdfViewer('#root')">
    <div id="root"></div>
</body>
</html>
```

### PDFビューワへのライセンスの適用
GcPdfViewer のインスタンスを作成して初期化する前に、PDFビューワのライセンスキーを GcPdfViewer.License プロパティに設定します。
なお、これは jsファイルを参照するコードの前に記述する必要があります。

```javascript
  // ご自身のライセンスを追加してください
  GcPdfViewer.LicenseKey = 'xxx';
  // 適宜コードを追加してください
  const viewer = new GcPdfViewer('#root', { file: 'helloworld.pdf' });
  viewer.addDefaultPanels();
```

### PDFビューワの検索オプション
PDFビューワには、以下のようなテキストの検索オプションが用意されていますが、**英語のみの対応**となっており、日本語は正しく検索できない場合があります。
- 大/小文字を区別
- 単語単位で検索
- 単語の先頭を検索
- 単語の末尾を検索
- ワイルドカード
- 近接

上記検索オプションを非表示にしたい場合は、ページの`<head>`部分に以下のとおりCSSスタイルを追加してください。
```HTML
<style>
    .gc-viewer .search .search__query-params > label:nth-child(1),
    .gc-viewer .search .search__query-params > label:nth-child(2),
    .gc-viewer .search .search__query-params > label:nth-child(3),
    .gc-viewer .search .search__query-params > label:nth-child(4),
    .gc-viewer .search .search__query-params > label:nth-child(5),
    .gc-viewer .search .search__query-params > label:nth-child(6) {
        display: none;
    }
</style>
```

### <a id="support_api_ja"></a>サポートAPI
_サポートAPI_ は、NuGetパッケージ
「[GrapeCity.DioDocs.Pdf.ViewerSupportApi.ja](https://www.nuget.org/packages/GrapeCity.DioDocs.Pdf.ViewerSupportApi.ja/)」として
提供されるサーバーサイドのライブラリです。
このライブラリの完全なソースコードは、ASP.&#8203;NET CoreおよびWeb FormsのC＃デモプロジェクトとともに、
パッケージ内の「 __src/__ 」フォルダに含まれています（Web Formsのために **WEB_FORMS** 定数が定義されています）。
サーバーの構築方法として、パッケージを参照するか、または代わりにソースプロジェクトを含めてそれを参照するか、選ぶことができます。

PDFビューワがサポートAPIサーバーに接続されている場合、編集機能が有効になります。
クライアント上で行われた編集は蓄積され、ユーザーが「保存」をクリックすると、
元のPDFと編集内容がサーバーに送られて、編集が（GcPdfを使って）適用され、
変更されたPDFがクライアントに送り返されます。

サポートAPIサーバーをセットアップして動作を確認するには、
[PDFビューワの製品デモ](https://demo.grapecity.com/diodocs/pdfviewer/demos/)から任意のサンプルをダウンロードし
（例：[PDFの編集](https://demo.grapecity.com/diodocs/pdfviewer/demos/edit-pdf/purejs)）、
ダウンロードしたzipに含まれるreadme.&#8203;mdの説明をご参照ください。

なお、サポートAPIを使用するには、有効なDioDocs for PDFのライセンスが必要です。
ライセンスは、GcPdfDocumentのSetLicenseKey静的メソッドにて設定します。以下は、ASP.&#8203;NET Coreプロジェクトの「Startup.cs」にてDioDocs for PDFライセンスをサポートAPIに適用する例です。
```C#
public class Startup
{
    static Startup()
    {
        // 略
        GcPdfDocument.SetLicenseKey("ライセンスキー");
    }
    // 略
}
```

### キーボードのショートカット
#### 表示モード
- ```Ctrl +``` - 拡大
- ```Ctrl -``` - 縮小
- ```Ctrl 0``` - 100％に拡大
- ```Ctrl 9``` - ページ幅に合わせて拡大
- ```Ctrl A``` - すべて選択
- ```R``` - ドキュメントを右回りに回転
- ```Shift R``` - ドキュメントを左回りに回転
- ```H``` - 手のひらツールを有効化
- ```S``` - 選択ツールを有効化
- ```Ctrl O``` - PDFファイルを開く
- ```Ctrl F``` - テキスト検索
- ```Ctrl P``` - 印刷
- ```Home``` - 行頭に移動
- ```Ctrl Home``` - ドキュメントの先頭に移動
- ```Shift Home``` - 行頭まで選択
- ```Shift Ctrl Home``` - ドキュメントの先頭まで選択
- ```End``` - 行末に移動
- ```Ctrl End``` - ドキュメントの末尾に移動
- ```Shift End``` - 行末まで選択
- ```Shift Ctrl End``` - ドキュメントの末尾まで選択
- ```Left``` - 左に移動
- ```Shift Left``` - 左を選択
- ```Alt Left``` - 前の履歴に戻る
- ```Right``` - 右に移動
- ```Shift Right``` - 右を選択
- ```Alt Right``` - 次の履歴に進む
- ```Up``` - 上に移動
- ```Shift Up``` - 上まで選択
- ```Down``` - 下に移動
- ```Shift Down``` - 下まで選択
- ```PgUp``` - 前のページに移動
- ```PgDown``` - 次のページに移動
- ```Shift PgUp``` - 前のページまで選択
- ```Shift PgDown``` - 次のページまで選択

#### 編集モード
- ```Delete``` - 選択した注釈/フィールドを削除
- ```Esc``` - 注釈/フィールドの選択を解除
- ```Ctrl Z``` - 元に戻す
- ```Ctrl Y``` - やり直す
- ```Ctrl Shift Z``` - やり直す

### ツールバーの項目
PDFビューワのデフォルトのツールバーレイアウトは以下のとおりです。（'$'で始まる項目は、ビューワの標準として備わっているものであり、それ以外の項目はPDFビューワ固有のものになります。）
```
['open', '$navigation', '$split', 'text-selection', 'pan', '$zoom', '$fullscreen', 'rotate', 'view-mode', 'theme-change', 'download', 'print', 'save', 'hide-annotations', 'doc-title', 'doc-properties', 'about']
```

PDFビューワ固有のツールバー項目は以下のとおりです。
```
'text-selection', 'pan', 'open', 'save', 'download', 'print', 'rotate', 'theme-change', 'doc-title', 'view-mode', 'single-page', 'continuous-view'
```

ビューワの標準のツールバー項目は以下のとおりです。
```
'$navigation' '$refresh', '$history', '$mousemode', '$zoom', '$fullscreen', '$split'
```

以下のように、getDefaultToolbarItems() メソッドを使用することで、デフォルトのツールバー項目を取得することができます。
```javascript
const toolbar: Toolbar = viewer.toolbar;
let buttons = toolbar.getDefaultToolbarItems();
buttons = buttons.filter(b => b !== '$refresh');
```

ツールバー項目をカスタマイズするには、以下のように toolbarLayout プロパティと applyToolbarLayout() メソッドを使用します。
```javascript
viewer.toolbarLayout.viewer = {
  default: ["$navigation", 'open', '$split', 'doc-title'],
  fullscreen: ['$fullscreen', '$navigation'],
  mobile: ["$navigation", 'doc-title']
};
viewer.toolbarLayout.annotationEditor = {
  default: ['edit-select', 'save', '$split', 'edit-text'],
  fullscreen: ['$fullscreen', 'edit-select', 'save', '$split', 'edit-text'],
  mobile: ['$navigation']
};
viewer.toolbarLayout.formEditor = {
  default: ['edit-select-field', 'save', '$split', 'edit-widget-tx-field', 'edit-widget-tx-password'],
  fullscreen: ['$fullscreen', 'edit-select-field', 'save', '$split', 'edit-widget-tx-field', 'edit-widget-tx-password'],
  mobile: ['$navigation']
};
viewer.applyToolbarLayout();
```

以下のように、独自のカスタムツールバーボタンを作成することもできます。
```javascript
const toolbar: Toolbar = viewer.toolbar;
toolbar.addItem({
  key: 'my-custom-button',
  iconCssClass: 'mdi mdi-bike',
  title: 'カスタムボタン',
  enabled: false,
  action: () => {
    alert("カスタムツールバーボタンがクリックされました");
  },
  onUpdate: (args) => ({ enabled: viewer.hasDocument }),
});
viewer.toolbarLayout.viewer.default =  ['$navigation', 'my-custom-button'];
viewer.applyToolbarLayout();
```

### React、Preact、AngularなどのフレームワークでのPDFビューワの使用
PDFビューワのスクリプトへの参照を追加します。
```HTML
<body>
  <script type="text/javascript" src="/lib/gcpdfviewer/gcpdfviewer.js"></script>
  ...
```

アプリのテンプレートに以下のようにプレースホルダを追加します。
```HTML
<section id="pdf"></section>
```

PDFビューワをレンダリングします。
```javascript
let viewer = new GcPdfViewer('section#pdf');
viewer.addDefaultPanels();
```

---
_The End._
