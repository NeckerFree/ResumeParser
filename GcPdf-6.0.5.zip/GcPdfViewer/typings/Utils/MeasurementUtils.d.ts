export declare function measureDomString(text: string, fontSize: number, fontFamily?: string): {
    w: number;
    h: number;
};
