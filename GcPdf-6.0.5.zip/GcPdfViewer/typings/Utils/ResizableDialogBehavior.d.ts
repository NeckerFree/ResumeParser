export declare function ensureResizableDialogBehavior(dialog: HTMLElement, dragHandleClass?: string, allowResize?: boolean, minHeight?: number, minWidth?: number): void;
