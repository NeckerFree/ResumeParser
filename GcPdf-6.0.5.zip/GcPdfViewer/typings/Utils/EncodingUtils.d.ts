declare function unicodeToChar(text: string): string;
declare function htmlDecode(input: string): string;
declare function fasterBytesToBase64(arrayOrArrayBuffer: ArrayBuffer | ArrayLike<number> | ArrayBufferLike): string;
declare function bytesToBase64(bytes: any): string;
declare function base64ToBytes(dataURI: string): Uint8Array;
declare function utf8ToBase64(str: string): string;
declare function base64ToUtf8(str: string): string;
export { utf8ToBase64, base64ToUtf8, bytesToBase64, base64ToBytes, fasterBytesToBase64, unicodeToChar, htmlDecode };
