import { OptionalContentConfig } from "../Models/ViewerTypes";
export declare type LayersModel = {
    config: OptionalContentConfig | null;
};
export declare type LayersMsg = {
    type: 'reset';
};
