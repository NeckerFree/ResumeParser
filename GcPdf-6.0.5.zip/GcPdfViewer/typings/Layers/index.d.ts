export { Layers as View } from './Layers';
