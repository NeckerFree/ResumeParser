import 'core-js/es/set';
import 'core-js/es/map';
import 'core-js/web/';
import 'blob-polyfill';
import { GcPdfViewer } from './GcPdfViewer';
export { GcPdfViewer };
export { ViewerOptions } from './ViewerOptions';
export default GcPdfViewer;
