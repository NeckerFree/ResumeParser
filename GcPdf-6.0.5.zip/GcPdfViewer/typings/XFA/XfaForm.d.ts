import GcPdfViewer from "..";
export declare class XfaForm {
    viewer: GcPdfViewer;
    constructor(viewer: GcPdfViewer);
    recalculate: (arg: any) => {};
    execInitialize: () => {};
}
