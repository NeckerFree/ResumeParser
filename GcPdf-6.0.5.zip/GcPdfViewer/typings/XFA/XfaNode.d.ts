export declare class XfaNode {
    name: string;
    rawValue: string;
    constructor(name: string, rawValue: string);
}
