//@ts-ignore
import { MouseMode } from "@grapecity/viewer-core";
export declare type FloatingBarProps = {};
export declare type FloatingBarModel = {
    visible: boolean;
    mouseMode: MouseMode;
};
