export { Thumbnails as View } from './Thumbnails';
