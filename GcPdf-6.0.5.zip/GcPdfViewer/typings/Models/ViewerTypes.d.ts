import { SignatureInfo } from "../SupportApi/ISupportApi";
export declare type FieldAppearanceRenderingType = "Custom" | "Web" | "Predefined";
export declare type OpenParameters = {
    headers: {
        [header: string]: string;
    };
    withCredentials: boolean;
    password: string;
};
export declare type OptionalContentConfig = {
    creator: null | string;
    name: null | string;
    getGroup(id: string): OptionalContentGroup;
    getGroups(): {
        [id: string]: OptionalContentGroup;
    };
    getOrder(): {
        name: string | null;
        order: string[];
    }[];
    isVisible(groupOrId: string | OptionalContentGroup): any;
    setVisibility(id: string, visible: boolean): any;
};
export declare type OptionalContentGroup = {
    id: string;
    name: string;
    type: "OCG" | string;
    visible: boolean;
    exportState?: "ON" | "OFF";
    viewState?: "ON" | "OFF";
    printState?: "ON" | "OFF";
    creatorInfo?: {
        Creator: string;
        Subtype: string;
    };
    intent?: "View" | "Design";
    zoom?: {
        min?: number;
        max?: number;
    };
};
export declare type StructTreeNode = {
    role: "Root" | string;
    children: Array<StructTreeNode | StructTreeContent>;
};
export declare type StructTreeContent = {
    id: string;
    type: "content" | "object";
    actualText: string | undefined;
};
export declare type ViewerFeatureName = 'JavaScript' | 'AllAttachments' | 'FileAttachments' | 'SoundAttachments' | 'DragAndDrop' | 'SubmitForm' | 'Print';
export declare type StampCategory = {
    id: string;
    name: string;
    stampImages: string[];
    stampImageUrls?: string[];
    isDynamic: boolean;
    dpi: number;
};
export interface IPageViewport {
    offsetX: number;
    offsetY: number;
    rotation: number;
    scale: number;
    transform: number;
    viewBox: number[];
    width: number;
    height: number;
}
export interface IGcPageView {
    viewport: IPageViewport;
    ensureFullyLoaded(): Promise<IGcPageView>;
    ensureSelectionPainter(): Promise<any>;
    ensureAnnotationLayerRendered(): Promise<any>;
    pageIndex: number;
    width: number;
    height: number;
    renderingId: string;
    renderingState: any;
    outputScale: any;
    scale: number;
    rotation: number;
}
export interface IGcVisiblePage {
    id: number;
    view: IGcPageView;
    x: number;
    y: number;
    percent: number;
}
export interface IGcVisiblePagesInfo {
    first: IGcVisiblePage;
    last: IGcVisiblePage;
    views: IGcVisiblePage[];
}
export interface IGcSelectionCopier {
    showTextMarkupContextMenu(event: MouseEvent | TouchEvent, coords?: {
        clientX: number;
        clientY: number;
    }): boolean;
    showCustomContextMenu(event: MouseEvent | TouchEvent, coords?: {
        clientX: number;
        clientY: number;
    }): boolean;
    copySelectedText(): boolean;
    printSelectedText(): any;
    resetAll(): any;
    resetPage(pageIndex: number): any;
    beginUpdatePages(): any;
    endUpdatePages(): any;
    beginUpdatePage(pageIndex: number): any;
    endUpdatePage(): any;
    getSelectedText(): any;
    notifyCaretPositionChanged(x: number, y: number, pageIndex: number): any;
    notifyViewerFocused(viewer: any): any;
    onNativeContextMenuStart(): any;
    onNativeContextMenuEnd(): any;
    hasSelectedText: boolean;
    currentSelectionBox: null | {
        pageIndex: number;
        x: number;
        y: number;
        w: number;
        h: number;
        paintedBoxes: {
            pageIndex: number;
            x: number;
            y: number;
            w: number;
            h: number;
            angle: number;
            dir: "ltr" | "rtl";
            vertical: boolean;
        }[];
    };
}
export declare type SaveSettings = {
    format?: "PDF" | "PNG";
    pages?: string;
    reload?: boolean;
    saveMode?: "Auto" | "Default" | "Linearized" | "IncrementalUpdate";
    saveModificationsOnly?: boolean;
    sign?: SignatureInfo;
};
export declare type PageViewport = {
    viewBox: number[];
    width: number;
    height: number;
    scale: number;
    rotation: number;
    offsetX: number;
    offsetY: number;
    transform: number[];
    clone(args: Partial<PageViewport>): PageViewport;
    convertToViewportPoint(x: number, y: number): number[];
    convertToViewportRectangle(rect: number[]): number[];
    convertToPdfPoint(x: any, y: any): number[];
};
