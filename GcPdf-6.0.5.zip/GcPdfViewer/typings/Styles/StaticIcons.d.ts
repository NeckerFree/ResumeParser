export declare function getSvgIconMarkup(iconName: 'accepted' | 'cancelled' | 'completed' | 'rejected'): string;
