export declare type Message = {
    correlationId?: string;
};
