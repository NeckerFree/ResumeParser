import GcPdfViewer from "..";
import { SaveSettings } from "../Models/ViewerTypes";
import { ViewerOptions } from "../ViewerOptions";
export declare class DocumentOptions {
    constructor(clientID: string, options: ViewerOptions, docViewer: GcPdfViewer, saveSettings?: SaveSettings);
    clientID: string;
    friendlyFileName: string;
    fileUrl: string;
    fileName: string;
    password: string;
    userData?: any;
    userName: string;
    saveSettings?: SaveSettings;
}
