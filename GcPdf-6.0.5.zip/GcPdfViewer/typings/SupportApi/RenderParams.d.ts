export declare type RenderParams = {
    renderInteractiveForms: boolean;
    viewport: {
        scale: number;
        rotation: number;
    };
};
