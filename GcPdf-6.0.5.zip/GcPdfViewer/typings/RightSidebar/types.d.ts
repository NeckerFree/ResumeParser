export declare type GcRightSidebarTool = 'none' | 'reply-tool' | 'merge-pdf' | 'split-pdf';
export declare type GcRightSidebarState = 'collapsed' | 'expanded' | 'hidden';
