//@ts-ignore
import { DropdownItem } from "@grapecity/core-ui";
import { IGcDocumentContextMenuContext } from "./types";
import GcPdfViewer from "..";
import { GcSelectionPoint } from "../Models/GcMeasurementTypes";
/// <reference path="../vendor/i18next.d.ts" />
//@ts-ignore
import { i18n } from 'i18next';
import { IGcSelectionCopier } from "../Models/ViewerTypes";
export declare type GcContextMenuParams = {
    mouseOverPageFlag: boolean;
    keyboardEventFlag: boolean;
    target?: HTMLElement;
    event?: any;
};
export declare class GcDocumentContextMenu {
    viewer: GcPdfViewer;
    container: HTMLElement;
    context: IGcDocumentContextMenuContext;
    docViewer: any;
    private _openParams;
    private _targetAnnotationId;
    private _opening;
    private _opened;
    in17n: i18n;
    static register(viewer: GcPdfViewer, container: HTMLElement, context: IGcDocumentContextMenuContext, docViewer: any): void;
    static unregister(container: HTMLElement): void;
    mousePosition: GcSelectionPoint;
    insertPosition: GcSelectionPoint;
    private constructor();
    onTextMarkupContextMenu(mousePos: GcSelectionPoint, selectionCopier: IGcSelectionCopier, params: GcContextMenuParams): boolean;
    onCustomContextMenu(mousePos: GcSelectionPoint, selectionCopier: IGcSelectionCopier, params: GcContextMenuParams): boolean;
    private open;
    private openInternal;
    private close;
    private get contextMenuProvider();
    private getTextMarkupDropdownItems;
    private getDropdownItems;
    addShowCommentPanel(items: DropdownItem[], isMini?: boolean): void;
    addPasteAction(items: DropdownItem[], isMini?: boolean): void;
    addAnnotationMenuItems(items: DropdownItem[], annotationId: string, isMini?: boolean): void;
    addSplitter(items: DropdownItem[]): void;
    getDDColorValues(): {
        value: string;
        displayName: string;
    }[];
    renderColorItems(colors: {
        value: string;
        displayName: string;
    }[], onClick: (colorHex: string) => void): DropdownItem[];
    addHighlightFromSelection(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isOverAnnotation: boolean, isMini?: boolean): void;
    addUnderlineFromSelection(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isOverAnnotation: boolean, isMini?: boolean): void;
    addStrikeoutFromSelection(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isOverAnnotation: boolean, isMini?: boolean): void;
    addSquigglyFromSelection(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isOverAnnotation: boolean, isMini?: boolean): void;
    addCreateLinkAndTextMarkupItems(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isOverAnnotation: boolean, isMini?: boolean): void;
    addCopyText(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isMini?: boolean): void;
    addPrint(items: DropdownItem[], selectionCopier: IGcSelectionCopier, isMini?: boolean): void;
    addStickyNote(items: DropdownItem[], isMini?: boolean): void;
    private _convertFromGlobalPoint;
    private _findTargetAnnotationElement;
    private _isTargetAllowsDefaultContextMenu;
}
