export interface IGcDocumentContextMenuContext {
}
