import { AnnotationBase } from './AnnotationTypes';
export declare function renderAnnotationStatusContent(annotation: AnnotationBase, annotations: AnnotationBase[], userName: string): JSX.Element | null;
