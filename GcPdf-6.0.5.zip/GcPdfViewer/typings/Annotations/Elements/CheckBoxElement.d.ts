export declare class CheckBoxElement {
}
