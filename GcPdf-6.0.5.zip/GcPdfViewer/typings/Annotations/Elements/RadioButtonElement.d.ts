export declare class RadioButtonElement {
}
