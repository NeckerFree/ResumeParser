import { ColorEditorLocalization } from "./types";
export declare function getColorEditorLocalization(in17n: any): ColorEditorLocalization;
