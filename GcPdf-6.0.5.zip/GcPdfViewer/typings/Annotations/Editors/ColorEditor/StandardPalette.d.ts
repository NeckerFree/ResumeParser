//@ts-ignore
import { Color } from "@grapecity/core-ui";
export declare function getStandardPalette(): Color[][];
