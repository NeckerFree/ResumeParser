export { AttachmentsMsg as Msg, AttachmentsModel as Model } from './types';
export { init, update } from './state';
export { Attachments as View } from './Attachments';
