/// <reference path="vendor/i18next.d.ts" />
//@ts-ignore
import { i18n } from 'i18next';
//@ts-ignore
import { ViewerStatus, ViewMode, Toolbar, ToolbarLayout, ZoomMode } from '@grapecity/viewer-core';
import PdfReportPlugin from './plugin';
import { SignToolSettings, ViewerOptions } from './ViewerOptions';
/// <reference path="vendor/react/react.d.ts" />
//@ts-ignore
import React from 'react';
/// <reference path="vendor/react/react-dom.d.ts" />
//@ts-ignore
import * as ReactDOM from 'react-dom';
//@ts-ignore
import { ReportViewer, LoadResult, EventFan } from '@grapecity/viewer-core';
import { SvgIconKey } from './Styles/pdfSvgIcons';
import { ISupportApi, OpenDocumentInfo } from './SupportApi/ISupportApi';
import { PdfToolbarLayout } from './Toolbar/PdfToolbarLayout';
import { AnnotationBase, AnnotationTypeCode, CopyBufferData, FileAttachmentAnnotation, WidgetAnnotation, SignatureInformation } from './Annotations/AnnotationTypes';
import { EditMode, LayoutMode } from './Annotations/types';
import { GcSelectionPoint } from './Models/GcMeasurementTypes';
import { GcRightSidebarState } from './RightSidebar/types';
import { GcRightSidebar } from './RightSidebar/GcRightSidebar';
import { LogLevel, ModificationsState, UndoChangeName } from './SharedDocuments/types';
import { SharedRef } from './Utils/SharedRef';
import { GcPdfSearcher } from './Search/GcPdfSearcher';
//@ts-ignore
import { PanelHandle } from '@grapecity/viewer-core/types/api/PluginModel';
import { DataStorage } from './DataStorage/DataStorage';
import { GcMeasurement } from './Utils/GcMeasurement';
import { SignToolStorage } from './SignTool/SignToolStorage';
import { LeftSidebar } from './LeftSidebar';
import { DocumentSecuritySummary } from './Security/DocumentSecuritySummary';
import { DocumentInformation } from './Properties/DocumentInformation';
import { OpenParameters, OptionalContentConfig, PageViewport, SaveSettings, StructTreeNode, ViewerFeatureName } from './Models/ViewerTypes';
import { AddStampDropdown } from './Toolbar/controls/AddStampDropdown';
import { SecondToolbar } from './Toolbar/SecondToolbar/SecondToolbar';
import { SecondToolbarLayout, SecondToolbarLayoutMode } from './Toolbar/SecondToolbar/types';
import { SearchPanel } from './Search/SearchPanel';
import { utf8ToBase64 } from './Utils/EncodingUtils';
import { ErrorEventArgs, BeforeOpenEventArgs, AfterOpenEventArgs, ThemeChangedEventArgs, EventName, EventArgs, BeforeAddAnnotationEventArgs, AfterAddAnnotationEventArgs, AfterUpdateAnnotationEventArgs, BeforeRemoveAnnotationEventArgs, AfterRemoveAnnotationEventArgs, BeforeUpdateAnnotationEventArgs } from './Models/EventArgs';
import { XfaApiImpl } from './XFA/XfaApiImpl';
export declare class GcPdfViewer extends ReportViewer {
    private static _i18n;
    static _instanceCounter: number;
    private _disposed;
    private _plugin;
    private _isUpdating;
    private _toolbarLayout;
    private _secondToolbarLayout;
    private _viewerInstanceId;
    readonly in17n: i18n;
    private _fileStorage;
    addStampDropdown: AddStampDropdown | null;
    private _secondToolbar;
    private _editorLastValues;
    private _xfa;
    constructor(element: HTMLElement | string, options?: Partial<ViewerOptions>);
    get hasAttachments(): boolean;
    get attachments(): FileAttachmentAnnotation[];
    get instanceId(): string;
    set instanceId(id: string);
    get isEditModeSticked(): boolean;
    get isPureXfa(): boolean;
    getSignatureInfo(): Promise<SignatureInformation>;
    pdfStringToDate(input?: string | Date): Date | null;
    get sharedRef(): SharedRef;
    get dataLoader(): import("./Core/GcPdfViewerDataLoader").GcPdfViewerDataLoader;
    get eventBus(): any;
    get editorLastValues(): any;
    get formStateHelper(): any;
    get annotationStateHelper(): any;
    getEditorLastValue(annotation: AnnotationBase, propertyName: string): any;
    saveToEditorLastValues(annotation: AnnotationBase): Promise<void>;
    private _filterLastValues;
    get requiredSupportApiVersion(): string;
    get supportApiVersion(): string;
    get gcPdfVersion(): string;
    get serviceProvider(): any;
    static LicenseKey: string;
    get canEditDocument(): boolean;
    get currentUserName(): string;
    set currentUserName(userName: string);
    get disableFeaturesHash(): {
        [key in ViewerFeatureName]?: boolean;
    };
    get editMode(): EditMode;
    set editMode(mode: EditMode);
    activateEditMode(mode: EditMode, args?: {
        editMode: EditMode;
        imageUrl: string;
        imageDpi: number;
        w: number;
        h: number;
        imageDataKey?: string;
    } | null): void;
    get fileData(): Uint8Array | null;
    get fileName(): string;
    get fileUrl(): string;
    get isInEditorMode(): boolean;
    get activatedEditorMode(): "SecondBar" | "FormEditor" | "AnnotationEdtor" | "Any" | "" | undefined;
    get leftSidebar(): LeftSidebar;
    get storage(): DataStorage;
    get signToolStorage(): SignToolStorage;
    get hasChanges(): boolean;
    get changesVersion(): number;
    get hasCopyData(): boolean;
    get hasDocument(): boolean;
    get hideAnnotations(): boolean;
    set hideAnnotations(hide: boolean);
    get layoutMode(): LayoutMode;
    set layoutMode(mode: LayoutMode);
    get logLevel(): LogLevel;
    set logLevel(logLvel: LogLevel);
    get modificationsState(): ModificationsState;
    get optionalContentConfig(): Promise<OptionalContentConfig>;
    get structureTree(): Promise<StructTreeNode[] | null>;
    scrollMarkedTextIntoView(pageIndex: number, id: string): Promise<void>;
    get options(): Partial<ViewerOptions>;
    set options(options: Partial<ViewerOptions>);
    getType(typeName: string): typeof React | typeof AnnotationBase | typeof ReactDOM | typeof GcPdfViewer | typeof PdfReportPlugin | typeof AnnotationTypeCode | typeof utf8ToBase64 | typeof EditMode | typeof ViewerStatus | typeof ViewerOptions | typeof LayoutMode | typeof Toolbar | typeof ViewMode | typeof ZoomMode | typeof GcMeasurement | typeof GcPdfSearcher | typeof GcRightSidebar | null;
    get plugin(): PdfReportPlugin;
    get rotation(): number;
    set rotation(degrees: number);
    get searcher(): GcPdfSearcher;
    get searchPanelHandle(): PanelHandle | undefined;
    get searchPanel(): SearchPanel | undefined;
    get supportApi(): ISupportApi | null;
    get toolbarLayout(): PdfToolbarLayout;
    set toolbarLayout(toolbarLayout: PdfToolbarLayout);
    get secondToolbarLayout(): SecondToolbarLayout;
    set secondToolbarLayout(layout: SecondToolbarLayout);
    get version(): string;
    get hasReplyTool(): boolean;
    get rightSidebar(): GcRightSidebar;
    get fingerprint(): string;
    static get i18n(): i18n;
    get annotations(): Promise<{
        pageIndex: number;
        annotations: AnnotationBase[];
    }[]>;
    get beforeUnloadConfirmation(): boolean;
    set beforeUnloadConfirmation(enable: boolean);
    get hasForm(): boolean;
    get hasPersistentConnection(): boolean;
    showFormFiller(): void;
    showSignTool(preferredSettings?: SignToolSettings): void;
    resetChanges(): Promise<void>;
    reload(keepUndoState?: boolean): Promise<void>;
    get hasUndoChanges(): boolean;
    get hasUndo(): boolean;
    get hasRedoChanges(): boolean;
    get hasRedo(): boolean;
    get undoStore(): any;
    get undoState(): (0 | {
        changeName: UndoChangeName;
        selectedAnnotation: {
            pageIndex: number;
            annotation: AnnotationBase;
        } | null;
        data: any;
    })[];
    get undoIndex(): number;
    get undoCount(): number;
    get pageIndex(): number;
    set pageIndex(val: number);
    get pageCount(): number;
    findTargetPageForRect(rect: number[]): number;
    get isDocumentShared(): boolean;
    set zoomValue(val: number);
    get zoomValue(): number;
    set zoomMode(val: ZoomMode);
    messageBox(cMsg: string | any, nIcon?: number, nType?: number, cTitle?: string, oDoc?: any, oCheckbox?: any): number;
    alert(cMsg: string | any, nIcon?: number, nType?: number, cTitle?: string, oDoc?: any, oCheckbox?: any): number;
    resetData(): void;
    beep(param: number): void;
    execMenuItem(menuItem: string): Promise<any>;
    get xfa(): XfaApiImpl;
    get zoomMode(): ZoomMode;
    get onError(): EventFan<ErrorEventArgs>;
    get onBeforeOpen(): EventFan<BeforeOpenEventArgs>;
    get onAfterOpen(): EventFan<AfterOpenEventArgs>;
    get onBeforeAddAnnotation(): EventFan<BeforeAddAnnotationEventArgs>;
    get onAfterAddAnnotation(): EventFan<AfterAddAnnotationEventArgs>;
    get onBeforeUpdateAnnotation(): EventFan<BeforeUpdateAnnotationEventArgs>;
    get onAfterUpdateAnnotation(): EventFan<AfterUpdateAnnotationEventArgs>;
    get onBeforeRemoveAnnotation(): EventFan<BeforeRemoveAnnotationEventArgs>;
    get onAfterRemoveAnnotation(): EventFan<AfterRemoveAnnotationEventArgs>;
    private _eventsDef;
    private _getEventFan;
    getEvent(eventName: EventName): EventFan<any>;
    triggerEvent(eventName: EventName, args?: EventArgs | ThemeChangedEventArgs | BeforeOpenEventArgs | AfterOpenEventArgs): void;
    get onThemeChanged(): EventFan<AfterOpenEventArgs>;
    static findControl(selector: string | HTMLElement): GcPdfViewer | undefined;
    get secondToolbar(): SecondToolbar;
    addViewAreaStyle(cssText: string): string;
    removeViewAreaStyle(id: string): boolean;
    static updateSvgIcon(iconKey: SvgIconKey, svgIcon: Element | string): void;
    static getSvgIcon(iconKey: SvgIconKey): Element;
    invalidate(): void;
    showSecondToolbar(toolbarKey: SecondToolbarLayoutMode | string): Promise<void>;
    hideSecondToolbar(): void;
    activateEditorMode(caller: "SecondBar" | "FormEditor" | "AnnotationEdtor"): void;
    deactivateEditorMode(caller: "SecondBar" | "ViewerLayout"): void;
    setPageTabs(pageIndex: number, tabs: "S" | "R" | "C" | "A" | "W" | undefined): void;
    getPageTabs(pageIndex: number): "S" | "R" | "C" | "A" | "W" | undefined;
    setPageRotation(pageIndex: number, rotation: number, viewRotationIncluded?: boolean): Promise<boolean>;
    getPageRotation(pageIndex: number, includeViewRotation?: boolean): number;
    dispose(): void;
    logError(method: string, message: string): void;
    logDebug(method: string, message: string): void;
    commitChanges(): void;
    cancelChanges(): void;
    close(): Promise<void>;
    open(file?: any | string | URL | Uint8Array | Array<number>, openParameters?: OpenParameters): Promise<LoadResult>;
    _openLockCap?: {
        promise: Promise<any>;
        resolve: Function;
        reject: Function;
    };
    lockOpen(): Promise<any>;
    unlockOpen(): Promise<void>;
    pdfUrlToFileName(url: string): string;
    openLocalFile(): any;
    newDocument(params?: {
        fileName?: string;
        confirm?: boolean;
    } | string): Promise<LoadResult | null>;
    newPage(params?: {
        width?: number;
        height?: number;
        pageIndex?: number;
    }): Promise<void>;
    deletePage(pageIndex?: number): Promise<void>;
    print(): void;
    download(fileName?: string): void;
    save(fileName?: string, settings?: SaveSettings): Promise<boolean>;
    saveAsImages(fileName?: string): Promise<boolean>;
    saveChanges(): Promise<boolean>;
    submitForm(submitUrl: string): void;
    resetForm(): void;
    getSubmitTransportForm(submitUrl: any, submitForm?: true | {
        fields: string[];
        refs: string[];
        include: boolean;
        includeNoValueFields: boolean;
        exportFormat: boolean;
        getMethod: boolean;
        submitCoordinates: boolean;
        xFDF: boolean;
        submitPDF: boolean;
        canonicalFormat: boolean;
    }): HTMLFormElement | null;
    get annotationStorage(): any;
    validateForm(validator?: (fieldValue: string | string[], field: WidgetAnnotation) => boolean | string, silent?: boolean, ignoreValidationAttrs?: boolean): string | boolean;
    getDocumentSecurity(): Promise<DocumentSecuritySummary>;
    getDocumentInformation(): Promise<DocumentInformation>;
    goToPageNumber(pageNumber: number): void;
    goToPage(pageIndex: number): void;
    goToFirstPage(): void;
    goToPrevPage(): void;
    goToNextPage(): void;
    goToLastPage(): void;
    scrollPageIntoView(params: {
        pageNumber: number;
        destArray?: any[];
        allowNegativeOffset?: boolean;
    }): void;
    loadAndScrollPageIntoView(pageIndex: number, destArray?: any[]): Promise<boolean>;
    get scrollView(): HTMLElement;
    setTheme(theme?: string): void;
    execCutAction(buffer?: CopyBufferData): Promise<boolean>;
    execCopyAction(buffer?: CopyBufferData): Promise<boolean>;
    execDeleteAction(buffer?: CopyBufferData): Promise<boolean>;
    execPasteAction(point?: GcSelectionPoint): Promise<boolean>;
    loadDocumentList(documentListUrl?: string): void;
    openPanel(panelHandleOrId: PanelHandle | string): void;
    closePanel(panelHandleOrId?: PanelHandle | string): void;
    addDefaultPanels(): PanelHandle[];
    addDocumentListPanel(documentListUrl?: string): PanelHandle;
    addSharedDocumentsPanel(): PanelHandle;
    addThumbnailsPanel(): PanelHandle;
    addSearchPanel(): PanelHandle;
    addAnnotationEditorPanel(): PanelHandle;
    addArticlesPanel(): PanelHandle;
    addAttachmentsPanel(): PanelHandle;
    addOutlinePanel(): PanelHandle;
    addStructureTreePanel(): PanelHandle;
    addLayersPanel(): PanelHandle;
    addFormEditorPanel(): PanelHandle;
    addReplyTool(sidebarState?: GcRightSidebarState): void;
    cloneAnnotation(annotation: AnnotationBase): AnnotationBase;
    getSelectedText(): string;
    pushModificationsState(modificationsState: ModificationsState): void;
    toViewPortPoint(point: GcSelectionPoint): GcSelectionPoint;
    addStickyNote(position: GcSelectionPoint): void;
    changeOriginToBottom(pageIndex: any, y: any): number;
    changeOriginToTop(pageIndex: any, y: any): number;
    changeOrigin(pageIndex: number, y: number, srcOrigin: 'TopLeft' | 'BottomLeft', destOrigin: 'TopLeft' | 'BottomLeft'): number;
    changeBoundsOrigin(pageIndex: number, bounds: number[], srcOrigin: 'TopLeft' | 'BottomLeft', destOrigin: 'TopLeft' | 'BottomLeft', normalize?: boolean): number[];
    getViewPort(pageIndex: number): PageViewport;
    getPageSize(pageIndex: number, includeScale?: boolean): {
        width: number;
        height: number;
    };
    setPageSize(pageIndex: number, size: {
        width: number;
        height: number;
    }): Promise<boolean>;
    addAnnotation(pageIndex: number, annotation: AnnotationBase, args?: {
        skipPageRefresh?: boolean;
    }): Promise<{
        pageIndex: number;
        annotation: AnnotationBase;
    }>;
    lockAnnotation(id: string | AnnotationBase): Promise<AnnotationBase | null>;
    unlockAnnotation(id: string | AnnotationBase): Promise<AnnotationBase | null>;
    addSignature(imageData: Uint8Array | null, args: {
        fileId: string;
        pageIndex: number;
        rect: number[];
        select?: boolean;
        subject?: string;
        fileName?: string;
        convertToContent?: boolean;
    }): Promise<{
        pageIndex: number;
        annotation: AnnotationBase;
    }>;
    addStamp(imageData: Uint8Array | null, args: {
        fileId: string;
        pageIndex: number;
        rect: number[];
        select?: boolean;
        subject?: string;
        fileName?: string;
        rotate?: number;
        convertToContent?: boolean;
    }): Promise<{
        pageIndex: number;
        annotation: AnnotationBase;
    }>;
    loadSharedDocuments(): void;
    openSharedDocument(sharedDocumentId: string): Promise<OpenDocumentInfo | null>;
    updateAnnotation(pageIndex: number, annotation: AnnotationBase, args?: {
        skipPageRefresh?: boolean;
    }): Promise<{
        pageIndex: number;
        annotation: AnnotationBase;
    }>;
    updateAnnotations(pageIndex: number, annotations: AnnotationBase | AnnotationBase[], args?: {
        skipPageRefresh?: boolean;
    }): Promise<{
        pageIndex: number;
        annotations: AnnotationBase[];
    }>;
    updateGroupFieldValue(fieldName: string, newValue: string, skipPageRefresh?: boolean): Promise<boolean>;
    removeAnnotation(pageIndex: number, annotationId: string, args?: {
        skipPageRefresh?: boolean;
    }): Promise<boolean>;
    findAnnotation(findString: string | number, findParams?: {
        findField?: 'id' | 'title' | 'contents' | 'fieldName' | string;
        pageNumberConstraint?: number;
        findAll?: boolean;
    }): Promise<{
        pageNumber: number;
        annotation: AnnotationBase;
    }[]>;
    findAnnotations(findString: string | number, findParams?: {
        findField?: 'id' | 'title' | 'contents' | 'fieldName' | string;
        pageIndexConstraint?: number;
        findAll?: boolean;
    }): Promise<{
        pageIndex: number;
        annotation: AnnotationBase;
    }[]>;
    selectAnnotation(pageIndex: number | string, annotation?: AnnotationBase | string): Promise<boolean>;
    unselectAnnotation(): any;
    scrollAnnotationIntoView(pageIndex: number, annotation: AnnotationBase): any;
    undoChanges(): void;
    undo(): void;
    redoChanges(): void;
    redo(): void;
    repaint(indicesToRepaint?: number[]): void;
    applyOptions(): void;
    applyToolbarLayout(): void;
    getAnnotationPageIndex(annotation: string | AnnotationBase): number | null;
    getPageLocation(pageIndex: number): {
        x: number;
        y: number;
    };
    setAnnotationBounds(annotationId: string, bounds: {
        x: number | undefined;
        y: number | undefined;
        w: number | undefined;
        h: number | undefined;
    }, origin?: 'TopLeft' | 'BottomLeft', select?: boolean): Promise<void>;
    getRenderedAnnotationBounds(id: string, windowRelative?: boolean): {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    globalPointToPagePoint(mousePosition: GcSelectionPoint): GcSelectionPoint;
    enablePdfToolButtons(buttons?: string[] | "all" | 'none'): void;
    updateLayout(layout: ToolbarLayout): void;
    showMessage(message: string, details?: string, severity?: "error" | "warn" | "info" | "debug"): void;
    clearMessages(): void;
    goBack(): void;
    goForward(): void;
    beginUpdate(): void;
    endUpdate(): void;
    get isUpdating(): boolean;
    private static _init_i18n;
}
export default GcPdfViewer;
