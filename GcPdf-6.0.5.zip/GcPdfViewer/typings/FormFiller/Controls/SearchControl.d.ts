import { ControlBase } from './ControlBase';
export declare class SearchControl extends ControlBase {
    render(): JSX.Element;
}
