import { ControlBase } from './ControlBase';
export declare class CombTextControl extends ControlBase {
    render(): JSX.Element;
}
