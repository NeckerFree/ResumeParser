import { ControlBase } from './ControlBase';
export declare class PasswordControl extends ControlBase {
    render(): JSX.Element;
}
