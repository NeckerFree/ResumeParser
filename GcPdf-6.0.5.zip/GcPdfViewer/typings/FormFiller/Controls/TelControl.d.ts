import { ControlBase } from './ControlBase';
export declare class TelControl extends ControlBase {
    render(): JSX.Element;
}
