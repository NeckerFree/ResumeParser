import { ControlBase } from './ControlBase';
export declare class EmailControl extends ControlBase {
    render(): JSX.Element;
}
