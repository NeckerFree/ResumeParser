import { ControlBase } from './ControlBase';
export declare class CheckBoxControl extends ControlBase {
    render(): JSX.Element;
}
