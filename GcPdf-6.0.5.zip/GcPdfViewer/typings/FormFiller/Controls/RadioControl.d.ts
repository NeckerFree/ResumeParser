import { ControlBase } from './ControlBase';
export declare class RadioControl extends ControlBase {
    render(): JSX.Element;
}
