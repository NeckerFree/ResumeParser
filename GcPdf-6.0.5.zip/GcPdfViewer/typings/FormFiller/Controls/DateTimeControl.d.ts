import { ControlBase } from './ControlBase';
export declare class DateTimeControl extends ControlBase {
    render(): JSX.Element;
}
