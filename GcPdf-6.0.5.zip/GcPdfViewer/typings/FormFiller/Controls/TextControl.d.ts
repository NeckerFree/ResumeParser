import { ControlBase } from './ControlBase';
export declare class TextControl extends ControlBase {
    render(): JSX.Element;
}
