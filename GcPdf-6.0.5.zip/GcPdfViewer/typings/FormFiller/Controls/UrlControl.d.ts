import { ControlBase } from './ControlBase';
export declare class UrlControl extends ControlBase {
    render(): JSX.Element;
}
