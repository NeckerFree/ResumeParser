export { StructureTree as View } from './StructureTree';
