import GcPdfViewer from "../../GcPdfViewer";
export declare function renderSecondToolbarControls(toolbarKey: string, viewer: GcPdfViewer): (JSX.Element | null)[] | null;
