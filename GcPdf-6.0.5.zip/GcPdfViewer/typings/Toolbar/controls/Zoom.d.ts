/// <reference path="../../vendor/react/react.d.ts" />
//@ts-ignore
import { Component } from 'react';
export declare const _MAX_ZOOM = 3, _MIN_ZOOM = 0.25;
//@ts-ignore
import { ZoomSettings } from '@grapecity/viewer-core';
import GcPdfViewer from '../../GcPdfViewer';
export declare type ZoomControlProps = {
    onChange?: (zoom: ZoomSettings) => void;
    viewer: GcPdfViewer;
};
export declare type ZoomControlModel = {
    openDropdown: boolean;
    disabled?: boolean;
    zoomInputValue?: string;
    version?: number;
};
export declare class ZoomControl extends Component<ZoomControlProps, ZoomControlModel> {
    _mounted: boolean;
    private _unregisterViewerStateChange?;
    private _zoomInput;
    private _dropdown;
    private _minZoom;
    private _maxZoom;
    constructor(props: ZoomControlProps, context?: any);
    componentDidMount(): void;
    componentWillUnmount(): void;
    private onDecButtonClick;
    private onIncButtonClick;
    private incZoomInternal;
    private decZoomInternal;
    private onZoomSelect;
    clearDirty(): void;
    _inputFocused: boolean;
    getValueFromState(useDefaultFromControl?: boolean): string;
    onInputKeyDown(e: KeyboardEvent): boolean;
    render(): JSX.Element;
    setZoomInputValue(zoomInputValue?: string): void;
    get minZoom(): number;
    get maxZoom(): number;
    applyZoomInputValue(): void;
}
