import { Annotations } from "../Annotations";
export declare class AcroForm extends Annotations {
}
