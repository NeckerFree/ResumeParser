export declare class GcPdfPrintService {
    private readonly _viewer;
    private readonly _docViewer;
    constructor(_viewer: any, _docViewer: any);
    print(): void;
    printWithProgressDialog(): void;
}
