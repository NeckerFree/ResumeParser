declare function arrayFrom(arr: any, callbackFn: any, thisArg: any): any[];
