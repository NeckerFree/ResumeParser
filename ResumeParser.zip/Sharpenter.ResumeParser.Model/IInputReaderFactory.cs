﻿namespace Sharpenter.ResumeParser.Model
{
    public interface IInputReaderFactory
    {
        IInputReader LoadInputReaders();
    }
}
