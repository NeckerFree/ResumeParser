﻿namespace Sharpenter.ResumeParser.Model
{
    public class Education
    {
        public string School { get; set; }
        public string Course { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}
