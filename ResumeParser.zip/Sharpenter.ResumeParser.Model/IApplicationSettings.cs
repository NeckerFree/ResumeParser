﻿namespace Sharpenter.ResumeParser.Model
{
    public interface IApplicationSettings
    {
        string InputReaderLocation { get; }
    }
}
